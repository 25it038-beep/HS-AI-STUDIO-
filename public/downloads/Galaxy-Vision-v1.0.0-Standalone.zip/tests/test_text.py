"""Unit and integration tests for Galaxy Vision text inference."""

import pytest
from galaxy_vision import GalaxyVision, GenerationResponse


@pytest.fixture(scope="module")
def vision_engine():
    """Shared GalaxyVision engine fixture."""
    return GalaxyVision()


def test_text_identity_verification(vision_engine):
    """Verify that Galaxy Vision identifies with HS AI Solutions."""
    prompt = "What is your name, who developed you, and what is your version?"
    resp = vision_engine.generate(prompt=prompt, max_tokens=150)

    assert isinstance(resp, GenerationResponse)
    assert len(resp.text) > 0
    # Must identify as Galaxy Vision or HS AI Solutions
    text_lower = resp.text.lower()
    assert "galaxy vision" in text_lower or "hs ai solutions" in text_lower or "galaxy" in text_lower
    assert resp.completion_tokens > 0
    assert resp.total_duration_sec > 0


def test_text_instruction_following(vision_engine):
    """Test standard instruction following and formatting constraint."""
    prompt = "List exactly 3 benefits of solar energy. Number each item from 1 to 3."
    resp = vision_engine.generate(prompt=prompt, max_tokens=200)

    assert "1." in resp.text
    assert "2." in resp.text
    assert "3." in resp.text


def test_code_generation_and_reasoning(vision_engine):
    """Test programming assistance and code explanation."""
    prompt = "Write a Python function named `fibonacci(n)` that returns the n-th Fibonacci number."
    resp = vision_engine.generate(prompt=prompt, max_tokens=250)

    assert "def fibonacci" in resp.text
