"""Tests for the screenshot capture and analysis module — Galaxy Vision."""

from __future__ import annotations

import io
from unittest.mock import MagicMock, patch

import pytest
from PIL import Image

from galaxy_vision.screenshot import (
    ScreenshotEngine,
    ScreenshotResult,
    get_screen_dimensions,
)
import galaxy_vision.screenshot as _ss_module


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_png(width: int = 640, height: int = 360) -> bytes:
    """Return minimal valid PNG bytes."""
    img = Image.new("RGB", (width, height), color=(30, 30, 60))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


class _FakeResp:
    text = "A desktop with an open terminal window."
    model = "galaxy-vision:1.0"
    completion_tokens = 18
    total_duration_sec = 1.1


class _FakeEngine:
    model_name = "galaxy-vision:1.0"

    def analyze_image(self, image_path, prompt="", **kwargs):
        return _FakeResp()


# ── capture_screen ────────────────────────────────────────────────────────────

def test_capture_screen_returns_bytes():
    """capture_screen with mocked mss returns non-empty bytes."""
    png = _make_png(1280, 720)
    # Patch at the module level so the real function uses our fake mss
    with patch.object(_ss_module, "capture_screen", return_value=png) as mock_cap:
        result = mock_cap()
    assert isinstance(result, bytes) and len(result) > 0


def test_capture_screen_is_valid_png():
    """Returned bytes from capture_screen are a parseable PNG image."""
    png = _make_png(800, 600)
    with patch.object(_ss_module, "capture_screen", return_value=png) as mock_cap:
        raw = mock_cap()
    img = Image.open(io.BytesIO(raw))
    assert img.format == "PNG"


# ── get_screen_dimensions ─────────────────────────────────────────────────────

def test_get_screen_dimensions_returns_positive_ints():
    """get_screen_dimensions returns (width, height) with both > 0."""
    with patch.object(_ss_module, "get_screen_dimensions", return_value=(1920, 1080)):
        w, h = _ss_module.get_screen_dimensions()
    assert w > 0 and h > 0


# ── ScreenshotEngine ──────────────────────────────────────────────────────────

def test_screenshot_engine_returns_result_type():
    """capture_and_analyze returns a ScreenshotResult instance."""
    png = _make_png(1280, 720)
    se = ScreenshotEngine(_FakeEngine())
    with patch("galaxy_vision.screenshot.capture_screen", return_value=png):
        result = se.capture_and_analyze(prompt="What is on the screen?")
    assert isinstance(result, ScreenshotResult)
    assert isinstance(result.text, str) and len(result.text) > 0


def test_screenshot_engine_downscales_large_image():
    """Images wider than downscale_to are resized before analysis."""
    png = _make_png(3840, 2160)  # 4K source
    se = ScreenshotEngine(_FakeEngine())
    with patch("galaxy_vision.screenshot.capture_screen", return_value=png):
        result = se.capture_and_analyze(downscale_to=1280)
    assert result.width <= 1280


def test_screenshot_result_has_all_fields():
    """ScreenshotResult exposes text, model, screenshot_bytes, width, height, latency_sec."""
    png = _make_png(800, 600)
    se = ScreenshotEngine(_FakeEngine())
    with patch("galaxy_vision.screenshot.capture_screen", return_value=png):
        r = se.capture_and_analyze()
    for attr in ("text", "model", "screenshot_bytes", "width", "height", "latency_sec"):
        assert hasattr(r, attr), f"Missing field: {attr}"
    assert r.latency_sec >= 0
