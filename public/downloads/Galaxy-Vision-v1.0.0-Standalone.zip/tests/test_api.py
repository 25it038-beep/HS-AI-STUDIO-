"""Unit and integration tests for Galaxy Vision FastAPI server."""

import base64
import io
import pytest
from fastapi.testclient import TestClient
from PIL import Image, ImageDraw
from galaxy_vision.api import app

client = TestClient(app)


def test_api_root_web_interface():
    """Verify GET / returns 200 HTML web interface."""
    response = client.get("/")
    assert response.status_code == 200
    assert "HS AI Solutions" in response.text
    assert "Galaxy Vision" in response.text


def test_api_health_endpoint():
    """Verify GET /health returns 200 with system diagnostics."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert data["product"] == "HS AI Solutions Galaxy Vision"
    assert "ollama" in data
    assert "system_ram" in data


def test_api_models_endpoint():
    """Verify GET /v1/models returns model catalog."""
    response = client.get("/v1/models")
    assert response.status_code == 200
    data = response.json()
    assert data["object"] == "list"
    assert len(data["data"]) >= 1
    model_entry = data["data"][0]
    assert "galaxy-vision" in model_entry["id"]


def test_api_chat_completions():
    """Verify POST /v1/chat/completions."""
    payload = {
        "messages": [
            {"role": "user", "content": "Respond with the word 'CONFIRMED' only."}
        ],
        "temperature": 0.1,
        "max_tokens": 50
    }
    response = client.post("/v1/chat/completions", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["object"] == "chat.completion"
    assert len(data["choices"]) > 0
    content = data["choices"][0]["message"]["content"]
    assert len(content) > 0


def test_api_vision_json():
    """Verify POST /v1/vision/analyze:json with base64 image."""
    img = Image.new("RGB", (200, 100), color=(10, 50, 80))
    d = ImageDraw.Draw(img)
    d.text((20, 40), "FASTAPI VISION", fill=(255, 255, 255))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64_str = base64.b64encode(buf.getvalue()).decode("utf-8")

    payload = {
        "image_base64": b64_str,
        "prompt": "Read the text in this image."
    }
    response = client.post("/v1/vision/analyze:json", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "text" in data
    assert "FASTAPI" in data["text"] or "VISION" in data["text"]


def test_api_batch_analyze():
    """Verify POST /v1/batch/analyze processes all uploaded files and verifies results."""
    # Image 1
    img1 = Image.new("RGB", (150, 80), color=(20, 40, 80))
    d1 = ImageDraw.Draw(img1)
    d1.text((15, 30), "BATCH FILE 1", fill=(255, 255, 255))
    buf1 = io.BytesIO()
    img1.save(buf1, format="PNG")

    # Image 2
    img2 = Image.new("RGB", (150, 80), color=(80, 20, 40))
    d2 = ImageDraw.Draw(img2)
    d2.text((15, 30), "BATCH FILE 2", fill=(255, 255, 255))
    buf2 = io.BytesIO()
    img2.save(buf2, format="PNG")

    files = [
        ("files", ("test_batch_1.png", buf1.getvalue(), "image/png")),
        ("files", ("test_batch_2.png", buf2.getvalue(), "image/png"))
    ]
    data = {"prompt": "What text is shown?"}

    response = client.post("/v1/batch/analyze", data=data, files=files)
    assert response.status_code == 200
    res_data = response.json()
    assert res_data["total_files"] == 2
    assert res_data["processed_successfully"] == 2
    assert res_data["all_files_verified"] is True
    assert len(res_data["results"]) == 2
    for item in res_data["results"]:
        assert item["status"] == "verified_processed"
        assert len(item["summary"]) > 0

