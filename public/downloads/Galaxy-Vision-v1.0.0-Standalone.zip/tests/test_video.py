"""Unit and integration tests for video frame sampling and temporal synthesis."""

import tempfile
from pathlib import Path
import cv2
import numpy as np
import pytest
from galaxy_vision import GalaxyVision
from galaxy_vision.video import VideoProcessor, format_timestamp


@pytest.fixture(scope="module")
def vision_engine():
    return GalaxyVision()


@pytest.fixture(scope="module")
def sample_video_file():
    """Create a temporary 2-second video file with numbered frames."""
    temp_dir = tempfile.mkdtemp()
    video_path = Path(temp_dir) / "test_clip.mp4"
    fps = 10
    duration_sec = 2

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(str(video_path), fourcc, fps, (320, 240))

    for i in range(duration_sec * fps):
        frame = np.zeros((240, 320, 3), dtype=np.uint8)
        cv2.putText(frame, f"FRAME {i}", (40, 120), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
        out.write(frame)
    out.release()

    yield video_path


def test_timestamp_formatting():
    """Test timestamp formatting utility."""
    assert format_timestamp(0.0) == "00:00:00.000"
    assert format_timestamp(65.5) == "00:01:05.500"


def test_frame_extraction(vision_engine, sample_video_file):
    """Test extracting frames from video file."""
    processor = VideoProcessor(vision_engine)
    frames, meta = processor.extract_frames(sample_video_file, sample_interval_sec=1.0, max_frames=5)

    assert len(frames) >= 2
    assert meta["duration_sec"] >= 1.9
    assert frames[0].timestamp_sec == 0.0
    assert len(frames[0].image_bytes) > 0


def test_video_analysis_pipeline(vision_engine, sample_video_file):
    """Test full video analysis pipeline."""
    res = vision_engine.analyze_video(
        video_path=sample_video_file,
        prompt="What text is displayed on the frames in this video?",
        sample_interval_sec=1.0,
        max_frames=3
    )

    assert res.sampled_frames_count >= 2
    assert "FRAME" in res.text or "frame" in res.text
    assert res.limitations != ""
    assert res.latency_sec > 0
