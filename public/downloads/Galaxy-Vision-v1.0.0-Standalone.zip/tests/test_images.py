"""Unit and integration tests for Galaxy Vision image and OCR capabilities."""

import io
import pytest
from PIL import Image, ImageDraw
from galaxy_vision import GalaxyVision, GenerationResponse
from galaxy_vision.vision import encode_image_to_base64, validate_and_preprocess_image


@pytest.fixture(scope="module")
def vision_engine():
    return GalaxyVision()


@pytest.fixture(scope="module")
def sample_ocr_image_bytes():
    """Create a synthetic high-contrast image containing known text."""
    img = Image.new("RGB", (320, 120), color=(20, 20, 40))
    d = ImageDraw.Draw(img)
    d.text((25, 45), "GALAXY-VISION-TEST-42", fill=(255, 255, 0))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def test_encode_and_validate_image(sample_ocr_image_bytes):
    """Test image encoding and validation routines."""
    b64 = encode_image_to_base64(sample_ocr_image_bytes)
    assert isinstance(b64, str)
    assert len(b64) > 100

    validated = validate_and_preprocess_image(sample_ocr_image_bytes, max_dimension=1024)
    assert isinstance(validated, bytes)
    assert len(validated) > 0


def test_image_ocr_accuracy(vision_engine, sample_ocr_image_bytes):
    """Verify that Galaxy Vision correctly transcribes text from the image."""
    resp = vision_engine.analyze_image(
        image_path=sample_ocr_image_bytes,
        prompt="Transcribe the exact text visible in this image."
    )
    assert isinstance(resp, GenerationResponse)
    assert "GALAXY" in resp.text
    assert "VISION" in resp.text


def test_image_visual_reasoning(vision_engine):
    """Verify visual reasoning about geometric shapes and colors."""
    img = Image.new("RGB", (250, 250), color=(255, 255, 255))
    d = ImageDraw.Draw(img)
    # Draw a green circle
    d.ellipse([50, 50, 200, 200], fill=(0, 200, 0))
    buf = io.BytesIO()
    img.save(buf, format="PNG")

    resp = vision_engine.analyze_image(
        image_path=buf.getvalue(),
        prompt="What geometric shape and color is displayed in the center of the image?"
    )
    text_lower = resp.text.lower()
    assert "circle" in text_lower or "disk" in text_lower or "round" in text_lower
    assert "green" in text_lower
