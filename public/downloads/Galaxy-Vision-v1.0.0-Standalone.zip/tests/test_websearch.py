"""Tests for the web search + AI synthesis module — Galaxy Vision."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from galaxy_vision.websearch import (
    SearchResult,
    WebSearchEngine,
    WebSearchResponse,
    build_search_context,
    search_web,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

_RESULTS = [
    SearchResult(
        title="Galaxy Vision by HS AI Solutions",
        url="https://example.com/galaxy",
        snippet="Galaxy Vision is a multimodal AI system for image and document understanding.",
    ),
    SearchResult(
        title="Multimodal AI Overview",
        url="https://example.com/multimodal",
        snippet="Multimodal AI combines vision and language to process diverse inputs.",
    ),
    SearchResult(
        title="Vision-Language Models Explained",
        url="https://example.com/vlm",
        snippet="VLMs process images and natural language to answer visual questions.",
    ),
]


class _FakeResp:
    text = "Galaxy Vision is a multimodal AI [Source 1]. It handles images and text [Source 2]."
    model = "galaxy-vision:1.0"
    completion_tokens = 30
    total_duration_sec = 1.8


class _FakeEngine:
    model_name = "galaxy-vision:1.0"

    def generate(self, prompt, **kwargs):
        return _FakeResp()


# ── build_search_context ──────────────────────────────────────────────────────

def test_context_includes_all_titles_and_urls():
    ctx = build_search_context("test", _RESULTS)
    for r in _RESULTS:
        assert r.title in ctx
        assert r.url in ctx


def test_context_empty_results_no_crash():
    ctx = build_search_context("nothing", [])
    assert isinstance(ctx, str) and len(ctx) > 0


# ── search_web (mocked DDGS) ──────────────────────────────────────────────────

def test_search_web_returns_search_result_list():
    fake_raw = [{"title": r.title, "href": r.url, "body": r.snippet} for r in _RESULTS]
    mock_ddgs = MagicMock()
    mock_ddgs.__enter__ = MagicMock(return_value=mock_ddgs)
    mock_ddgs.__exit__ = MagicMock(return_value=False)
    mock_ddgs.text = MagicMock(return_value=fake_raw)

    with patch("galaxy_vision.websearch.DDGS", return_value=mock_ddgs):
        results = search_web("Galaxy Vision AI", max_results=3)

    assert isinstance(results, list)
    assert len(results) == 3
    assert all(isinstance(r, SearchResult) for r in results)


def test_search_result_fields_are_strings():
    r = _RESULTS[0]
    assert isinstance(r.title, str)
    assert isinstance(r.url, str)
    assert isinstance(r.snippet, str)


# ── WebSearchEngine ───────────────────────────────────────────────────────────

def test_engine_returns_web_search_response():
    wse = WebSearchEngine(_FakeEngine())
    with patch("galaxy_vision.websearch.search_web", return_value=_RESULTS):
        resp = wse.search_and_answer("What is multimodal AI?", max_results=3)
    assert isinstance(resp, WebSearchResponse)
    assert isinstance(resp.answer, str) and len(resp.answer) > 0


def test_engine_sources_match_results():
    wse = WebSearchEngine(_FakeEngine())
    with patch("galaxy_vision.websearch.search_web", return_value=_RESULTS):
        resp = wse.search_and_answer("Galaxy Vision", max_results=3)
    assert len(resp.sources) == len(_RESULTS)
    for src in resp.sources:
        assert "title" in src and "url" in src


def test_engine_num_results_used():
    wse = WebSearchEngine(_FakeEngine())
    with patch("galaxy_vision.websearch.search_web", return_value=_RESULTS):
        resp = wse.search_and_answer("AI models", max_results=3)
    assert resp.num_results_used == len(_RESULTS)


def test_engine_handles_empty_results_gracefully():
    wse = WebSearchEngine(_FakeEngine())
    with patch("galaxy_vision.websearch.search_web", return_value=[]):
        resp = wse.search_and_answer("xyzzy_nonexistent", max_results=3)
    assert isinstance(resp, WebSearchResponse)
    assert resp.num_results_used == 0
    assert isinstance(resp.answer, str)
