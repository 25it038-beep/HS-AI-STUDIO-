"""Unit tests for the Galaxy Vision desktop application launcher."""

from __future__ import annotations

import unittest
from unittest.mock import MagicMock, patch

from galaxy_vision.desktop import _find_available_port, _is_port_in_use


class TestDesktopApp(unittest.TestCase):
    def test_find_available_port(self):
        port = _find_available_port(8900)
        self.assertIsInstance(port, int)
        self.assertGreaterEqual(port, 8900)

    @patch("socket.socket.connect_ex", return_value=1)
    def test_is_port_in_use_false(self, mock_connect):
        self.assertFalse(_is_port_in_use(9999))

    @patch("socket.socket.connect_ex", return_value=0)
    def test_is_port_in_use_true(self, mock_connect):
        self.assertTrue(_is_port_in_use(9999))
