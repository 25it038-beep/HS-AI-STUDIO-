"""Unit and integration tests for document and structured extraction."""

import io
import pytest
from PIL import Image, ImageDraw
from galaxy_vision import GalaxyVision
from galaxy_vision.document_processing import DocumentProcessor


@pytest.fixture(scope="module")
def vision_engine():
    return GalaxyVision()


@pytest.fixture(scope="module")
def sample_table_image():
    """Create a synthetic tabular receipt image."""
    img = Image.new("RGB", (400, 200), color=(255, 255, 255))
    d = ImageDraw.Draw(img)
    d.text((30, 20), "RECEIPT #101", fill=(0, 0, 0))
    d.text((30, 60), "Item: Widget A", fill=(0, 0, 0))
    d.text((250, 60), "Cost: $15.00", fill=(0, 0, 0))
    d.text((30, 100), "Item: Widget B", fill=(0, 0, 0))
    d.text((250, 100), "Cost: $25.00", fill=(0, 0, 0))
    d.text((30, 150), "Total: $40.00", fill=(0, 0, 0))

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def test_document_ocr_and_structure(vision_engine, sample_table_image):
    """Verify document processing extracts textual content and numbers."""
    doc_proc = DocumentProcessor(vision_engine)
    res = doc_proc.process_document(
        document_path=sample_table_image,
        prompt="Extract all text and prices from this receipt.",
        extract_tables=True,
        return_json=True
    )

    assert "RECEIPT" in res.text
    assert "Widget" in res.text or "40" in res.text
    assert res.latency_sec > 0
