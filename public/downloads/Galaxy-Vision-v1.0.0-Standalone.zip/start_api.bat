@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

title Galaxy Vision Studio - HS AI Solutions

echo.
echo ================================================================
echo   HS AI Solutions Galaxy Vision 1.0.0
echo   Multimodal Vision-Language AI System
echo   ----------------------------------------------------------------
echo   Studio URL : http://localhost:8080
echo   API Docs   : http://localhost:8080/docs
echo   Backend    : Direct GGUF / Local Inference
echo   ----------------------------------------------------------------
echo   HS AI SOLUTIONS : https://hs-ai-studio-4i7i.vercel.app/
echo ================================================================
echo.

:: Step 1: Activate virtual environment if present
if exist ".venv\Scripts\activate.bat" (
    call ".venv\Scripts\activate.bat"
    echo [OK] Virtual environment activated.
) else (
    echo [INFO] Running with system Python.
)

:: Step 2: Verify Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.10+ or run setup.bat.
    pause
    exit /b 1
)

:: Step 3: Check package installation
python -c "import galaxy_vision" >nul 2>&1
if errorlevel 1 (
    echo [SETUP] Installing Galaxy Vision in editable mode...
    pip install -e . --quiet
)

:: Step 4: Ensure silent local inference daemon is running in background
where ollama >nul 2>&1
if not errorlevel 1 (
    netstat -ano | findstr /R /C:":11434 .*LISTENING" >nul 2>&1
    if errorlevel 1 (
        echo [INFO] Initializing inference engine daemon in background...
        start /b "" ollama serve >nul 2>&1
        timeout /t 2 /nobreak >nul 2>&1
    )
)

:: Step 5: Determine port (default 8080, fallback 8088)
set PORT=8080
netstat -ano | findstr /R /C:":8080 .*LISTENING" >nul 2>&1
if not errorlevel 1 (
    set PORT=8088
)

echo.
echo [STARTING] Launching Galaxy Vision Studio on http://localhost:!PORT!
echo [INFO] HS AI SOLUTIONS: https://hs-ai-studio-4i7i.vercel.app/
echo [INFO] Press Ctrl+C in this window to stop the server.
echo.

:: Automatically open browser
start "" "http://localhost:!PORT!"

:: Step 6: Start FastAPI server
python -m uvicorn galaxy_vision.api:app --host 0.0.0.0 --port !PORT! --log-level info

if errorlevel 1 (
    echo.
    echo [ERROR] Server exited with an error.
    pause
)
