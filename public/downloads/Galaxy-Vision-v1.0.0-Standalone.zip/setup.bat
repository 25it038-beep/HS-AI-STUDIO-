@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

title Galaxy Vision Setup - HS AI Solutions

echo.
echo ================================================================
echo   HS AI Solutions Galaxy Vision 1.0.0 - Setup
echo   Direct GGUF inference via llama-cpp-python
echo   No Ollama server required.
echo   HS AI SOLUTIONS : https://hs-ai-studio-4i7i.vercel.app/
echo ================================================================
echo.

:: Step 1: Python check
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo         Install Python 3.10+ from https://python.org
    pause
    exit /b 1
)
echo [OK] Python found.

:: Step 2: Create virtual environment
if not exist ".venv\Scripts\activate.bat" (
    echo [SETUP] Creating virtual environment...
    python -m venv .venv
)
call .venv\Scripts\activate.bat
echo [OK] Virtual environment active.

:: Step 3: Upgrade pip
python -m pip install --upgrade pip --quiet

:: Step 4: Install llama-cpp-python GPU wheel (CUDA 12.1)
echo.
echo [SETUP] Installing llama-cpp-python with CUDA GPU acceleration...
pip install llama-cpp-python --prefer-binary --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu121 --quiet
if errorlevel 1 (
    echo [WARN] GPU wheel unavailable. Falling back to default binary...
    pip install llama-cpp-python --prefer-binary --quiet
)
echo [OK] llama-cpp-python installed.

:: Step 5: Install remaining dependencies
echo [SETUP] Installing remaining dependencies...
pip install -r requirements.txt --quiet
echo [OK] Dependencies installed.

:: Step 6: Install Galaxy Vision package (editable)
pip install -e . --quiet
echo [OK] Galaxy Vision package installed.

:: Step 7: Verify GGUF model file
echo.
echo [CHECK] Locating Galaxy Vision GGUF model...
python -c "from galaxy_vision.config import get_config; c=get_config(); import pathlib; p=pathlib.Path(c.gguf_path); print('[OK]  GGUF found:', str(p), f'({p.stat().st_size//1048576} MB)') if p.is_file() else print('[WARN] GGUF not found at:', str(p))"

:: Step 8: Quick import check
python -c "from galaxy_vision import GalaxyVision; print('[OK] Galaxy Vision package imports successfully.')"
if errorlevel 1 (
    echo [ERROR] Import failed. Check the output above for details.
    pause
    exit /b 1
)

echo.
echo ================================================================
echo   Setup Complete!
echo.
echo   Launch Options:
echo     start_desktop.bat  - Launch Native Standalone Desktop Application
echo     start_web_ui.bat   - Launch Galaxy Vision Web Studio (port 8080)
echo     start_api.bat      - Launch API Server (port 8080)
echo     start_cli.bat      - Open Interactive Terminal CLI
echo.
echo   HS AI SOLUTIONS : https://hs-ai-studio-4i7i.vercel.app/
echo ================================================================
echo.
pause
