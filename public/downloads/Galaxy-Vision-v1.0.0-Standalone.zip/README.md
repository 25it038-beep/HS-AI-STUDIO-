# HS AI Solutions Galaxy Vision (v1.0.0)

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](pyproject.toml)
[![License](https://img.shields.io/badge/license-Apache%202.0-green.svg)](LICENSE)
[![Base Model](https://img.shields.io/badge/base%20model-Galaxy%20Vision%20Foundation%204.4B-6366f1.svg)](docs/UPSTREAM_MODEL_AUDIT.md)
[![Hardware Target](https://img.shields.io/badge/hardware-RTX%203050%20(6GB%20VRAM)-purple.svg)](docs/ARCHITECTURE.md)
[![Test Suite](https://img.shields.io/badge/tests-30%2F30%20passing-brightgreen.svg)](tests/)

**HS AI Solutions Galaxy Vision** is an independently packaged, branded multimodal vision-language AI system engineered by **HS AI Solutions** ([Studio & Projects](https://hs-ai-studio-4i7i.vercel.app/)). Galaxy Vision delivers advanced visual question answering, optical character recognition (OCR), layout analysis, and temporal video synthesis with hardware efficiency on 6 GB VRAM GPUs.

---

## Quick Start (No Ollama Required)

1. **Setup**: Run `setup.bat` to install dependencies and configure CUDA GPU acceleration.
2. **Native Desktop App**: Run `start_desktop.bat` (or `python desktop_app.py`) for the standalone desktop application window.
3. **Web Studio**: Run `start_web_ui.bat` or `start_api.bat` to open the custom Dark-Theme UI on `http://localhost:8080`.
4. **Interactive CLI**: Run `start_cli.bat` for interactive terminal conversation and search.

**HS AI SOLUTIONS**: https://hs-ai-studio-4i7i.vercel.app/

---

## Key Highlights

* **Brand & Grounded Identity:** Distinguishes visual observations from assumptions, eliminates hallucinations on ambiguous images, and admits uncertainty honestly.
* **Multimodal Vision:** High-resolution image captioning, object detection, diagram analysis, and multi-image comparison.
* **Document Intelligence & OCR:** End-to-end extraction from scanned pages, invoices, forms, and receipts with automatic Markdown table formatting and structured JSON extraction.
* **Video Frame Extraction & Synthesis:** Integrated OpenCV pipeline with timestamp tracking (sub-second precision) and chronological narrative synthesis.
* **Hardware Efficiency on 6GB VRAM:** Optimized memory parameters (`num_ctx 8192`, dynamic resolution capping) enabling stable local inference on Windows laptops with NVIDIA RTX 3050 GPUs without OOM errors or host RAM swapping.
* **Multi-Interface Support:** Native Python SDK, high-performance FastAPI HTTP service with custom HTML UI, and Rich-powered interactive CLI.
* **Direct GGUF Inference:** Runs directly on local hardware via `llama-cpp-python` with CUDA acceleration without requiring external servers.

---

## Architecture at a Glance

```
galaxy-vision/
├── Modelfile                     # Ollama model definition & system grounding
├── pyproject.toml                # Build configuration and dependencies
├── requirements.txt              # Production Python requirements
├── LICENSE                       # Apache License 2.0
├── NOTICE                        # Upstream copyright & legal attribution
├── THIRD_PARTY_NOTICES.md        # Open-source third-party dependencies
│
├── galaxy_vision/                # Core Python Package
│   ├── __init__.py               # Public API exports
│   ├── config.py                 # Environment-aware settings manager
│   ├── model_loader.py           # Backend discovery & registration
│   ├── inference.py              # Unified GalaxyVision engine
│   ├── vision.py                 # Image processing & aspect-ratio guards
│   ├── video.py                  # OpenCV video frame extraction pipeline
│   ├── document_processing.py    # Document OCR, table & JSON extraction
│   ├── api.py                    # Production FastAPI HTTP server
│   ├── cli.py                    # Terminal CLI utility
│   └── health.py                 # System RAM & GPU VRAM diagnostics
│
├── tests/                        # Automated Capability Test Suite (14 tests)
│   ├── test_text.py              # Identity, instruction & code tests
│   ├── test_images.py            # Vision & OCR tests
│   ├── test_documents.py         # Table & invoice parsing tests
│   ├── test_video.py             # OpenCV frame extraction tests
│   └── test_api.py               # FastAPI endpoint tests
│
├── examples/                     # Ready-to-Run Interactive Examples
│   ├── text_example.py           # Factual text generation
│   ├── image_example.py          # Synthetic visual inspection & OCR
│   ├── video_example.py          # Synthetic multi-phase video analysis
│   └── document_example.py       # Receipt & table intelligence
│
├── benchmarks/                   # 12-Category Capability Evaluation Harness
│   └── run_benchmarks.py         # Automated latency & VRAM profiling
│
└── docs/                         # Engineering Documentation
    ├── UPSTREAM_MODEL_AUDIT.md   # Base model verification report
    ├── ARCHITECTURE.md           # System design & memory budgeting
    ├── CAPABILITIES.md           # Technical capabilities catalog
    ├── INSTALLATION.md           # Windows PowerShell setup guide
    ├── LICENSE_COMPLIANCE.md     # Legal & IP boundary specification
    └── BENCHMARKS.md             # Empirical benchmark results
```

---

## Quickstart Guide

### 1. Installation

```powershell
cd galaxy-vision

# Create and activate virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Install in editable mode
pip install -e .
```

### 2. Register the Galaxy Vision Model

```powershell
ollama create galaxy-vision:1.0 -f Modelfile
```

Verify that the tag appears:
```powershell
ollama list
```

### 3. Python SDK Usage

```python
from galaxy_vision import GalaxyVision

# Initialize the model
model = GalaxyVision()

# 1. Text Generation
res = model.generate("Explain the difference between a CPU and a GPU.")
print(res.text)

# 2. Image Analysis
img_res = model.analyze_image(
    image_path="sample.png",
    prompt="Describe the objects and exact text visible in this image."
)
print(img_res.text)

# 3. Video Analysis
video_res = model.analyze_video(
    video_path="clip.mp4",
    prompt="Summarize the chronological sequence of events.",
    sample_interval_sec=1.0
)
print(video_res.text)

# 4. Document OCR & Table Extraction
doc_res = model.analyze_document(
    document_path="invoice.png",
    extract_tables=True,
    return_json=True
)
print(doc_res.structured_data)
```

### 4. Interactive CLI

```powershell
# Check system health & GPU memory
galaxy-vision health

# Run text generation
galaxy-vision text "What are the core operating principles of Galaxy Vision?"

# Analyze an image
galaxy-vision image "sample.png" --prompt "Transcribe all visible text."

# Analyze a video
galaxy-vision video "sample.mp4" --interval 1.0 --max-frames 8

# Start the local FastAPI server
galaxy-vision serve --host 127.0.0.1 --port 8000
```

### 5. Local HTTP REST API

When running `galaxy-vision serve`:
* **Interactive Swagger UI:** [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
* **Health Check:** `GET /health`
* **Chat Completions (OpenAI Compatible):** `POST /v1/chat/completions`
* **Vision Analysis:** `POST /v1/vision/analyze`
* **Video Frame Synthesis:** `POST /v1/video/analyze`
* **Document Intelligence:** `POST /v1/documents/analyze`

---

## Hardware Target: 6GB VRAM Optimization

Galaxy Vision is engineered specifically for Windows workstations and gaming laptops (such as the **NVIDIA GeForce RTX 3050 Laptop GPU** with **6 GB VRAM** and **16 GB System RAM**):

* **4.4B Parameters in Q4_K_M:** Consumes ~3.3 GB static VRAM.
* **Context Clamping (`num_ctx 8192`):** Constrains KV cache to ~1.15 GB, avoiding OOM errors or host paging thrashing.
* **Sequential Video Extraction:** OpenCV samples frames sequentially and resizes to 640x480, releasing intermediate buffers immediately to maintain stable memory usage.

---

## License & Attribution


