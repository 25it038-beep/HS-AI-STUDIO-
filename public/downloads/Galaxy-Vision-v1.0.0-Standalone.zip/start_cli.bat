@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

title Galaxy Vision CLI Studio - HS AI Solutions

echo.
echo ================================================================
echo   HS AI Solutions Galaxy Vision 1.0.0 CLI
echo   ----------------------------------------------------------------
echo   Backend         : Direct GGUF / Local Inference
echo   HS AI SOLUTIONS : https://hs-ai-studio-4i7i.vercel.app/
echo ================================================================
echo.

:: Step 1: Activate virtual environment if present
if exist ".venv\Scripts\activate.bat" (
    call ".venv\Scripts\activate.bat"
    echo [OK] Virtual environment activated.
)

:: Step 2: Ensure background engine daemon is running
where ollama >nul 2>&1
if not errorlevel 1 (
    netstat -ano | findstr /R /C:":11434 .*LISTENING" >nul 2>&1
    if errorlevel 1 (
        echo [INFO] Initializing inference engine daemon in background...
        start /b "" ollama serve >nul 2>&1
        timeout /t 2 /nobreak >nul 2>&1
    )
)

:: Step 3: Launch interactive CLI chat directly
python -m galaxy_vision.cli chat

if errorlevel 1 (
    echo.
    echo [INFO] Interactive session ended or encountered an issue.
    echo Running health diagnostics:
    python -m galaxy_vision.cli health
    pause
)
