"""Configuration module for HS AI Solutions Galaxy Vision.

Loads configuration from environment variables with sensible defaults.
Backend is llama-cpp-python (direct GGUF). No external server required.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# ── GGUF blob location inside the Ollama model cache ─────────────────────────
_OLLAMA_BLOB = (
    Path.home()
    / ".ollama"
    / "models"
    / "blobs"
    / "sha256-16b83be682148a4d8201dbf720ea7eace5de98b69f63f05e0c908b4d7977ecb5"
)

# Fallback: user may place GGUF anywhere and point GALAXY_GGUF_PATH at it
_DEFAULT_GGUF = str(os.getenv("GALAXY_GGUF_PATH", str(_OLLAMA_BLOB)))


@dataclass
class GalaxyVisionConfig:
    """Configuration settings for the Galaxy Vision system."""

    # ── Model Identity ──────────────────────────────────────────────────────
    model_name: str = "galaxy-vision:1.0"
    product_name: str = "HS AI Solutions Galaxy Vision"
    version: str = "1.0.0"
    developer: str = "HS AI Solutions"
    model_family: str = "Galaxy"

    # ── GGUF Backend (llama-cpp-python) ─────────────────────────────────────
    gguf_path: str = field(default_factory=lambda: _DEFAULT_GGUF)
    backend: str = "llama-cpp"          # always llama-cpp; field kept for API compat

    # GPU layers: -1 = auto (all layers on GPU), 0 = CPU-only
    n_gpu_layers: int = field(
        default_factory=lambda: int(os.getenv("GALAXY_N_GPU_LAYERS", "-1"))
    )
    # Number of CPU threads for prompt evaluation
    n_threads: int = field(
        default_factory=lambda: int(os.getenv("GALAXY_N_THREADS", "0"))
    )

    # ── Inference Hyperparameters ────────────────────────────────────────────
    temperature: float = field(
        default_factory=lambda: float(os.getenv("GALAXY_VISION_TEMPERATURE", "0.7"))
    )
    top_p: float = field(
        default_factory=lambda: float(os.getenv("GALAXY_VISION_TOP_P", "0.9"))
    )
    top_k: int = field(
        default_factory=lambda: int(os.getenv("GALAXY_VISION_TOP_K", "40"))
    )
    max_tokens: int = field(
        default_factory=lambda: int(os.getenv("GALAXY_VISION_MAX_TOKENS", "2048"))
    )
    context_length: int = field(
        default_factory=lambda: int(os.getenv("GALAXY_VISION_CONTEXT_LENGTH", "8192"))
    )
    request_timeout: float = field(
        default_factory=lambda: float(os.getenv("GALAXY_VISION_REQUEST_TIMEOUT", "300.0"))
    )

    # ── API Server ───────────────────────────────────────────────────────────
    api_host: str = field(
        default_factory=lambda: os.getenv("GALAXY_VISION_API_HOST", "127.0.0.1")
    )
    api_port: int = field(
        default_factory=lambda: int(os.getenv("GALAXY_VISION_API_PORT", "8000"))
    )
    api_key: Optional[str] = field(
        default_factory=lambda: os.getenv("GALAXY_VISION_API_KEY") or None
    )
    max_upload_mb: int = field(
        default_factory=lambda: int(os.getenv("GALAXY_VISION_MAX_UPLOAD_MB", "25"))
    )

    # ── Video Processing ─────────────────────────────────────────────────────
    video_sample_interval_sec: float = field(
        default_factory=lambda: float(os.getenv("GALAXY_VISION_VIDEO_SAMPLE_INTERVAL_SEC", "1.0"))
    )
    max_video_frames: int = field(
        default_factory=lambda: int(os.getenv("GALAXY_VISION_MAX_VIDEO_FRAMES", "16"))
    )

    def gguf_exists(self) -> bool:
        """Return True if the GGUF model file is present on disk."""
        return Path(self.gguf_path).is_file()


_CONFIG_INSTANCE: Optional[GalaxyVisionConfig] = None


def get_config() -> GalaxyVisionConfig:
    """Return the global singleton configuration instance."""
    global _CONFIG_INSTANCE
    if _CONFIG_INSTANCE is None:
        _CONFIG_INSTANCE = GalaxyVisionConfig()
    return _CONFIG_INSTANCE
