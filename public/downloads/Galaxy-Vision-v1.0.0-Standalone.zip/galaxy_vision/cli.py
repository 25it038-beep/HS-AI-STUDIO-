"""Command Line Interface (CLI) for HS AI Solutions Galaxy Vision."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from .config import GalaxyVisionConfig, get_config
from .health import get_system_health
from .inference import GalaxyVision
from .websearch import WebSearchEngine

console = Console()


@click.group()
@click.version_option(version="1.0.0", prog_name="Galaxy Vision")
def main():
    """HS AI Solutions Galaxy Vision CLI: Multimodal Vision-Language AI System."""
    pass


@main.command()
def health():
    """Display comprehensive system health, GPU VRAM, and model status."""
    console.print(Panel.fit("[bold cyan]Galaxy Vision System Health & Resource Diagnostics[/bold cyan]"))
    with console.status("[bold green]Querying system metrics and inference backend...[/bold green]"):
        h = get_system_health()

    # Table for Inference Backend
    t_model = Table(title="Model & Inference Backend")
    t_model.add_column("Component", style="cyan")
    t_model.add_column("Value", style="magenta")
    t_model.add_row("Status", f"[green]{h['status'].upper()}[/green]" if h['status'] == "healthy" else f"[red]{h['status'].upper()}[/red]")
    t_model.add_row("Product", h.get("product", "HS AI Solutions Galaxy Vision"))
    t_model.add_row("Model", h.get("target_model", "galaxy-vision"))
    t_model.add_row("Backend", h.get("backend", "llama-cpp-python"))
    t_model.add_row("GGUF Status", "Found" if h.get("gguf_found") else "Not Found")
    t_model.add_row("HS AI Solutions", "https://hs-ai-studio-4i7i.vercel.app/")
    console.print(t_model)

    # Table for Hardware Diagnostics
    t_hw = Table(title="Hardware & Memory Diagnostics")
    t_hw.add_column("Hardware Component", style="cyan")
    t_hw.add_column("Details", style="yellow")
    ram = h["system_ram"]
    t_hw.add_row("System RAM", f"Total: {ram['total_ram_mb']:.0f} MB | Free: {ram['available_ram_mb']:.0f} MB ({ram['percent_used']}% used)")

    gpu = h["gpu"]
    if gpu["available"] and gpu["devices"]:
        for dev in gpu["devices"]:
            t_hw.add_row("GPU Device", f"{dev['name']} ({dev.get('total_vram_mb', 0):.0f} MB VRAM)")
            t_hw.add_row("VRAM Usage", f"Used: {dev.get('used_vram_mb', 0):.0f} MB | Free: {dev.get('free_vram_mb', 0):.0f} MB")
    else:
        t_hw.add_row("GPU Device", "[yellow]No CUDA GPU directly detected or active in process[/yellow]")
    console.print(t_hw)


@main.command()
@click.argument("prompt")
@click.option("--temperature", "-t", type=float, default=None, help="Sampling temperature")
@click.option("--stream/--no-stream", default=True, help="Stream output chunks")
def text(prompt: str, temperature: float, stream: bool):
    """Generate text completion from a prompt."""
    engine = GalaxyVision()
    console.print(f"[bold green]Galaxy Vision ({engine.model_name}) thinking...[/bold green]\n")

    if stream:
        gen = engine.generate(prompt=prompt, temperature=temperature, stream=True)
        for chunk in gen:
            sys.stdout.write(chunk)
            sys.stdout.flush()
        print()
    else:
        resp = engine.generate(prompt=prompt, temperature=temperature, stream=False)
        console.print(resp.text)
        console.print(f"\n[dim]Latency: {resp.total_duration_sec:.2f}s | Speed: {resp.completion_tokens / (resp.eval_duration_sec or 1):.1f} tok/s[/dim]")


@main.command()
@click.argument("image_path", type=click.Path(exists=True))
@click.option("--prompt", "-p", default="Analyze this image in detail and describe its contents.", help="Prompt or question")
def image(image_path: str, prompt: str):
    """Analyze an image using the vision encoder."""
    engine = GalaxyVision()
    console.print(f"[bold cyan]Analyzing image '{Path(image_path).name}'...[/bold cyan]\n")
    with console.status("[bold green]Processing vision tokens...[/bold green]"):
        resp = engine.analyze_image(image_path=image_path, prompt=prompt)
    console.print(Panel(resp.text, title=f"Analysis: {Path(image_path).name}"))
    console.print(f"[dim]Generated in {resp.total_duration_sec:.2f}s via {resp.model}[/dim]")


@main.command()
@click.argument("video_path", type=click.Path(exists=True))
@click.option("--prompt", "-p", default="Provide a chronological summary of what happens in this video.", help="Prompt")
@click.option("--interval", "-i", type=float, default=1.0, help="Sampling interval in seconds")
@click.option("--max-frames", "-m", type=int, default=16, help="Maximum frames to sample")
def video(video_path: str, prompt: str, interval: float, max_frames: int):
    """Extract frames and synthesize a chronological summary of a video."""
    engine = GalaxyVision()
    console.print(f"[bold cyan]Processing video '{Path(video_path).name}' (sampling every {interval}s, max {max_frames} frames)...[/bold cyan]\n")
    with console.status("[bold green]Extracting keyframes and synthesizing narrative...[/bold green]"):
        res = engine.analyze_video(
            video_path=video_path,
            prompt=prompt,
            sample_interval_sec=interval,
            max_frames=max_frames
        )
    console.print(Panel(res.text, title=f"Chronological Summary: {Path(video_path).name}"))
    console.print(f"[dim]Sampled {res.sampled_frames_count} frames across {res.duration_sec:.1f}s video in {res.latency_sec:.2f}s[/dim]")
    console.print(f"[yellow]{res.limitations}[/yellow]")


@main.command()
@click.argument("doc_path", type=click.Path(exists=True))
@click.option("--prompt", "-p", default=None, help="Custom document prompt")
@click.option("--json-output/--no-json", default=False, help="Request structured JSON output")
def document(doc_path: str, prompt: str, json_output: bool):
    """Process a document image, receipt, or form for OCR and tables."""
    engine = GalaxyVision()
    console.print(f"[bold cyan]Processing document '{Path(doc_path).name}'...[/bold cyan]\n")
    with console.status("[bold green]Performing document OCR and structure recognition...[/bold green]"):
        res = engine.analyze_document(
            document_path=doc_path,
            prompt=prompt,
            extract_tables=True,
            return_json=json_output
        )
    console.print(Panel(res.text, title="Document Analysis"))
    if res.tables:
        console.print(f"[green]Extracted {len(res.tables)} table(s) from document.[/green]")
    if res.structured_data:
        console.print("\n[bold]Structured JSON Data:[/bold]")
        console.print_json(data=res.structured_data)
    console.print(f"[dim]Completed in {res.latency_sec:.2f}s[/dim]")


@main.command()
@click.option("--host", default=None, help="Host to bind (default: 127.0.0.1)")
@click.option("--port", default=None, type=int, help="Port to bind (default: 8000)")
def serve(host: str, port: int):
    """Start the local FastAPI model server."""
    import uvicorn
    cfg = get_config()
    bind_host = host or cfg.api_host
    bind_port = port or cfg.api_port

    console.print(Panel.fit(
        f"[bold green]Starting HS AI Solutions Galaxy Vision Server[/bold green]\n"
        f"API URL: [cyan]http://{bind_host}:{bind_port}[/cyan]\n"
        f"Swagger Docs: [cyan]http://{bind_host}:{bind_port}/docs[/cyan]\n"
        f"Model: [magenta]{cfg.model_name}[/magenta]"
    ))
    uvicorn.run("galaxy_vision.api:app", host=bind_host, port=bind_port, reload=False)


@main.command()
@click.argument("query")
@click.option("--max-results", "-m", type=int, default=5, help="Number of web sources")
def search(query: str, max_results: int):
    """Search the web in real-time and synthesize a grounded AI answer."""
    engine = GalaxyVision()
    console.print(Panel.fit(f"[bold cyan]Searching web for:[/bold cyan] {query}"))
    with console.status("[bold green]Fetching search results & synthesizing answer...[/bold green]"):
        wse = WebSearchEngine(engine)
        resp = wse.search_and_answer(query=query, max_results=max_results)

    console.print(Panel(Markdown(resp.answer), title="Grounded AI Answer", border_style="green"))

    if resp.sources:
        t_src = Table(title="Sources & Citations")
        t_src.add_column("#", style="cyan", width=4)
        t_src.add_column("Title", style="bold")
        t_src.add_column("URL", style="dim")
        for i, s in enumerate(resp.sources, 1):
            t_src.add_row(str(i), s.get("title", "Untitled"), s.get("url", ""))
        console.print(t_src)

    console.print(f"[dim]Completed in {resp.latency_sec:.2f}s | {resp.num_results_used} sources cited[/dim]")


@main.command()
def chat():
    """Launch interactive conversational chat session with Galaxy Vision."""
    console.print(Panel.fit(
        "[bold cyan]🌌 Galaxy Vision 1.0.0 — Interactive Terminal Studio[/bold cyan]\n"
        "[dim]HS AI Solutions · https://hs-ai-studio-4i7i.vercel.app/[/dim]\n"
        "[green]Commands: 'exit' or 'quit' to end | 'clear' to reset chat[/green]"
    ))

    try:
        engine = GalaxyVision()
    except Exception as exc:
        console.print(f"[bold red]Failed to initialize engine:[/bold red] {exc}")
        return

    from .context import get_context_manager
    import uuid

    mgr = get_context_manager()
    session_id = f"cli-{uuid.uuid4().hex[:8]}"
    session = mgr.get_or_create_session(session_id)

    while True:
        try:
            user_input = console.input("\n[bold cyan]You > [/bold cyan]").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Session closed.[/dim]")
            break

        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit", ":q"):
            console.print("[dim]Goodbye from Galaxy Vision![/dim]")
            break
        if user_input.lower() == "clear":
            session_id = f"cli-{uuid.uuid4().hex[:8]}"
            session = mgr.get_or_create_session(session_id)
            console.print("[dim]Chat history reset (new session started).[/dim]")
            continue

        model_messages, analysis = mgr.build_model_messages(
            session_id=session_id,
            current_user_message=user_input,
        )

        if analysis.get("resolved_context_note"):
            console.print(f"[dim yellow]ℹ {analysis['resolved_context_note']}[/dim yellow]")

        console.print("[bold green]Galaxy Vision > [/bold green]", end="")

        try:
            chunks = []
            for chunk in engine.chat(messages=model_messages, stream=True):
                sys.stdout.write(chunk)
                sys.stdout.flush()
                chunks.append(chunk)
            print()
            full_reply = "".join(chunks)
            mgr.register_turn(session_id, "user", user_input)
            mgr.register_turn(session_id, "assistant", full_reply)
        except Exception as exc:
            console.print(f"\n[red]Error generating response:[/red] {exc}")


@main.command()
@click.option("--port", "-p", type=int, default=None, help="Port to bind backend")
def desktop(port: int):
    """Launch the standalone native desktop application."""
    from .desktop import launch_desktop_app
    launch_desktop_app(port=port)


@main.command()
def audit():
    """Print the upstream model audit and licensing compliance declaration."""
    audit_file = Path(__file__).parent.parent / "docs" / "UPSTREAM_MODEL_AUDIT.md"
    if audit_file.exists():
        console.print(audit_file.read_text(encoding="utf-8"))
    else:
        console.print("[red]Audit file not found.[/red]")


if __name__ == "__main__":
    main()
