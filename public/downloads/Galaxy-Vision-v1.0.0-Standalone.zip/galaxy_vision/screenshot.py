"""Screenshot capture and live screen analysis module for Galaxy Vision.

Captures the full desktop or a specific region, encodes it, and sends
it through the multimodal vision pipeline for analysis.
"""

from __future__ import annotations

import base64
import io
import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

from PIL import Image

if TYPE_CHECKING:
    from .inference import GalaxyVision

logger = logging.getLogger("galaxy_vision.screenshot")


@dataclass
class ScreenshotResult:
    """Result of a live screen analysis."""
    text: str
    model: str
    screenshot_bytes: bytes
    width: int
    height: int
    region: Optional[str] = None
    latency_sec: float = 0.0
    captured_at: float = field(default_factory=time.time)


def capture_screen(monitor_index: int = 1, region: Optional[Dict[str, int]] = None) -> bytes:
    """Capture the full desktop or a custom region using mss.

    Args:
        monitor_index: Monitor number (1 = primary). Use 0 for all monitors combined.
        region: Optional dict with keys top, left, width, height for a crop region.
    Returns:
        Raw PNG bytes of the screenshot.
    """
    try:
        import mss
        import mss.tools

        with mss.mss() as sct:
            monitor = region if region else sct.monitors[monitor_index]
            sct_img = sct.grab(monitor)
            img = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()

    except ImportError:
        # Fallback to pyautogui if mss is unavailable
        import pyautogui
        pil_img = pyautogui.screenshot()
        if region:
            pil_img = pil_img.crop((
                region.get("left", 0),
                region.get("top", 0),
                region.get("left", 0) + region.get("width", pil_img.width),
                region.get("top", 0) + region.get("height", pil_img.height)
            ))
        buf = io.BytesIO()
        pil_img.save(buf, format="PNG")
        return buf.getvalue()


def get_screen_dimensions() -> Tuple[int, int]:
    """Return (width, height) of the primary monitor."""
    try:
        import mss
        with mss.mss() as sct:
            m = sct.monitors[1]
            return m["width"], m["height"]
    except Exception:
        try:
            import pyautogui
            return pyautogui.size()
        except Exception:
            return 1920, 1080


class ScreenshotEngine:
    """Live screen capture and visual analysis engine."""

    def __init__(self, engine: "GalaxyVision"):
        self.engine = engine

    def capture_and_analyze(
        self,
        prompt: str = "Analyze this screenshot and describe what is on the screen, including any text, applications, and notable UI elements.",
        monitor_index: int = 1,
        region: Optional[Dict[str, int]] = None,
        downscale_to: int = 1280,
        **kwargs
    ) -> ScreenshotResult:
        """Capture the screen and analyze it through Galaxy Vision."""
        start_t = time.perf_counter()

        # Capture raw PNG bytes
        raw_bytes = capture_screen(monitor_index=monitor_index, region=region)

        # Downscale for VRAM efficiency
        with Image.open(io.BytesIO(raw_bytes)) as img:
            w, h = img.size
            if w > downscale_to:
                scale = downscale_to / w
                new_size = (int(w * scale), int(h * scale))
                img = img.resize(new_size, Image.Resampling.LANCZOS)
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                raw_bytes = buf.getvalue()
                w, h = new_size

        resp = self.engine.analyze_image(image_path=raw_bytes, prompt=prompt, **kwargs)
        latency = time.perf_counter() - start_t

        region_label = f"{region}" if region else f"full_monitor_{monitor_index}"

        return ScreenshotResult(
            text=resp.text,
            model=resp.model,
            screenshot_bytes=raw_bytes,
            width=w,
            height=h,
            region=region_label,
            latency_sec=round(latency, 2)
        )
