"""Native Desktop Application for HS AI Solutions Galaxy Vision.

Runs the local FastAPI server in an isolated background thread and presents
the Galaxy Vision interface in a dedicated standalone native desktop window.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path
from typing import Optional

import uvicorn

from .api import app
from .config import get_config

logger = logging.getLogger("galaxy_vision.desktop")


def _is_port_in_use(port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def _find_available_port(start_port: int = 8080) -> int:
    port = start_port
    while _is_port_in_use(port):
        port += 1
    return port


def _start_server_thread(host: str, port: int) -> threading.Thread:
    """Run uvicorn in a daemon background thread."""
    def run():
        uvicorn.run(app, host=host, port=port, log_level="warning")

    server_thread = threading.Thread(target=run, daemon=True)
    server_thread.start()
    return server_thread


def _wait_for_server(url: str, timeout: float = 10.0) -> bool:
    """Poll health endpoint until server responds."""
    start = time.perf_counter()
    health_url = f"{url}/health"
    while time.perf_counter() - start < timeout:
        try:
            with urllib.request.urlopen(health_url, timeout=1.0) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def _launch_native_window(url: str, title: str = "Galaxy Vision — HS AI Solutions") -> bool:
    """Attempt to launch via pywebview for true native window."""
    try:
        import webview
        window = webview.create_window(
            title=title,
            url=url,
            width=1280,
            height=840,
            min_size=(960, 600),
            background_color="#08090c",
            text_select=True,
        )
        webview.start()
        return True
    except Exception as exc:
        logger.warning("pywebview launch failed, falling back to desktop app mode: %s", exc)
        return False


def _launch_desktop_app_mode(url: str) -> None:
    """Launch in standalone app mode using Microsoft Edge or Chrome."""
    edge_paths = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
    ]
    for p in edge_paths:
        if os.path.isfile(p):
            subprocess.Popen([p, f"--app={url}", "--window-size=1280,840"])
            return

    # Fallback to default browser
    import webbrowser
    webbrowser.open(url)


def launch_desktop_app(port: Optional[int] = None) -> None:
    """Main entrypoint to run Galaxy Vision as a desktop app."""
    chosen_port = port or _find_available_port(8080)
    host = "127.0.0.1"
    url = f"http://{host}:{chosen_port}"

    print("=" * 64)
    print("  HS AI Solutions Galaxy Vision 1.0.0 — Desktop Application")
    print(f"  App URL         : {url}")
    print("  HS AI SOLUTIONS : https://hs-ai-studio-4i7i.vercel.app/")
    print("=" * 64)
    print("\n[INFO] Starting local engine and window...")

    _start_server_thread(host, chosen_port)

    if not _wait_for_server(url, timeout=8.0):
        print(f"[WARN] Server health check timed out. Attempting to open {url} anyway.")

    # Try native webview first
    success = _launch_native_window(url)
    if not success:
        print("[INFO] Launching standalone app mode...")
        _launch_desktop_app_mode(url)
        # Keep process alive while user uses the app
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n[INFO] Exiting Galaxy Vision Desktop Application.")


if __name__ == "__main__":
    launch_desktop_app()
