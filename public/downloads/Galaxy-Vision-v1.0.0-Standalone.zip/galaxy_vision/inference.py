"""Core inference engine — Galaxy Vision.

Backend selection (automatic, in priority order):
  1. llama-cpp-python  — direct GGUF, no server needed (if installed + GGUF present)
  2. Ollama HTTP API   — local daemon fallback (if running)

The public GalaxyVision class API is identical regardless of which
backend is active, so the UI and API layers are fully decoupled.
"""

from __future__ import annotations

import base64
import io
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Tuple, Union

from PIL import Image

from .config import GalaxyVisionConfig, get_config
from .health import get_system_health
from .model_loader import ModelLoader

logger = logging.getLogger("galaxy_vision.inference")

# ── Galaxy Vision system prompt ───────────────────────────────────────────────
_SYSTEM_PROMPT = (
    "You are Galaxy Vision (version 1.0.0), a multimodal vision-language AI "
    "developed and distributed by HS AI Solutions as part of the Galaxy model family.\n\n"
    "Guidelines:\n"
    "1. Identify yourself as Galaxy Vision 1.0.0 by HS AI Solutions.\n"
    "2. Provide direct, rigorous, factual, clearly structured answers.\n"
    "3. When images are supplied, analyze them systematically — objects, text, layout, spatial relationships.\n"
    "4. Distinguish observations from assumptions. Never invent details absent from the image.\n"
    "5. Transcribe visible text with meticulous fidelity.\n"
    "6. State limitations clearly when an image is blurry, ambiguous, or low-resolution.\n"
    "7. Explain your operational scope honestly.\n"
)


# ── Response dataclass ────────────────────────────────────────────────────────

@dataclass
class GenerationResponse:
    """Standardised response from any Galaxy Vision backend."""
    text: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_duration_sec: float = 0.0
    load_duration_sec: float = 0.0
    eval_duration_sec: float = 0.0
    finish_reason: str = "stop"
    raw: Dict[str, Any] = field(default_factory=dict)


class GalaxyVisionInferenceError(Exception):
    """Raised when inference fails on all available backends."""


# ── Image helpers (shared) ────────────────────────────────────────────────────

def _to_png_bytes(image_input: Union[str, bytes, Path]) -> bytes:
    if isinstance(image_input, (str, Path)):
        with open(image_input, "rb") as f:
            raw = f.read()
    else:
        raw = image_input
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def _to_b64(image_input: Union[str, bytes, Path]) -> str:
    return base64.b64encode(_to_png_bytes(image_input)).decode()


def _downscale_b64(b64: str, max_px: int = 1280) -> str:
    raw = base64.b64decode(b64)
    img = Image.open(io.BytesIO(raw))
    w, h = img.size
    if w > max_px:
        scale = max_px / w
        img = img.resize((int(w * scale), int(h * scale)), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode()
    return b64


# ══════════════════════════════════════════════════════════════════════════════
# BACKEND A — llama-cpp-python (direct GGUF, preferred)
# ══════════════════════════════════════════════════════════════════════════════

class _LlamaCppBackend:
    """Direct GGUF inference via llama-cpp-python."""

    def __init__(self, config: GalaxyVisionConfig):
        self.config = config
        self._llm = None

    @staticmethod
    def available(config: GalaxyVisionConfig) -> bool:
        try:
            import llama_cpp  # noqa: F401
            return Path(config.gguf_path).is_file()
        except ImportError:
            return False

    def _load(self):
        if self._llm is not None:
            return
        from llama_cpp import Llama
        logger.info("Loading Galaxy Vision GGUF from %s", self.config.gguf_path)
        t0 = time.perf_counter()
        self._llm = Llama(
            model_path=self.config.gguf_path,
            n_ctx=self.config.context_length,
            n_gpu_layers=self.config.n_gpu_layers,
            n_threads=self.config.n_threads or None,
            verbose=False,
            chat_format="chatml",
        )
        logger.info("Model loaded in %.2fs", time.perf_counter() - t0)

    def generate(
        self,
        prompt: str,
        images_b64: Optional[List[str]] = None,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 40,
        max_tokens: int = 1024,
        stream: bool = False,
    ) -> Union[GenerationResponse, Generator[str, None, None]]:
        self._load()
        messages = [{"role": "system", "content": _SYSTEM_PROMPT}]
        stop = ["<|im_end|>", "<|endoftext|>"]

        if images_b64:
            parts = [
                {"type": "image_url",
                 "image_url": {"url": f"data:image/png;base64,{_downscale_b64(b64)}"}}
                for b64 in images_b64
            ]
            parts.append({"type": "text", "text": prompt})
            messages.append({"role": "user", "content": parts})
        else:
            messages.append({"role": "user", "content": prompt})

        return self.chat(
            messages=messages,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            max_tokens=max_tokens,
            stop=stop,
            stream=stream,
        )

    def chat(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 40,
        max_tokens: int = 1024,
        stop: Optional[List[str]] = None,
        stream: bool = False,
    ) -> Union[GenerationResponse, Generator[str, None, None]]:
        self._load()
        stop = stop or ["<|im_end|>", "<|endoftext|>"]
        t0 = time.perf_counter()
        if stream:
            return self._stream(messages, temperature, top_p, top_k, max_tokens, stop)

        result = self._llm.create_chat_completion(
            messages=messages, temperature=temperature, top_p=top_p,
            top_k=top_k, max_tokens=max_tokens, stop=stop, stream=False,
        )
        wall = time.perf_counter() - t0
        choice = result.get("choices", [{}])[0]
        usage = result.get("usage", {})
        return GenerationResponse(
            text=(choice.get("message", {}).get("content") or "").strip(),
            model=self.config.model_name,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            total_duration_sec=round(wall, 3),
            finish_reason=choice.get("finish_reason", "stop"),
            raw=result,
        )

    def _stream(self, messages, temperature, top_p, top_k, max_tokens, stop):
        for chunk in self._llm.create_chat_completion(
            messages=messages, temperature=temperature, top_p=top_p,
            top_k=top_k, max_tokens=max_tokens, stop=stop, stream=True,
        ):
            text = chunk.get("choices", [{}])[0].get("delta", {}).get("content", "")
            if text:
                yield text

    def health(self) -> Dict[str, Any]:
        gguf = Path(self.config.gguf_path)
        return {
            "backend": "llama-cpp",
            "gguf_found": gguf.is_file(),
            "gguf_path": str(gguf),
            "gguf_size_mb": round(gguf.stat().st_size / 1_048_576, 1) if gguf.is_file() else 0,
            "model_loaded": self._llm is not None,
        }


# ══════════════════════════════════════════════════════════════════════════════
# BACKEND B — Ollama HTTP daemon (fallback)
# ══════════════════════════════════════════════════════════════════════════════

class _OllamaBackend:
    """Ollama HTTP API backend (fallback when llama-cpp is unavailable)."""

    _OLLAMA_HOST = "http://127.0.0.1:11434"

    def __init__(self, config: GalaxyVisionConfig):
        self.config = config
        self.host = self._OLLAMA_HOST
        self._active_model: Optional[str] = None

    @staticmethod
    def available() -> bool:
        try:
            import httpx
            with httpx.Client(timeout=3.0) as c:
                r = c.get("http://127.0.0.1:11434/api/tags")
                return r.status_code == 200
        except Exception:
            return False

    def _resolve_model(self) -> str:
        """Pick the best available Galaxy model in Ollama."""
        if self._active_model:
            return self._active_model
        import httpx
        try:
            with httpx.Client(base_url=self.host, timeout=5.0) as c:
                data = c.get("/api/tags").json()
                names = [m["name"] for m in data.get("models", [])]
            # Prefer our custom model, fallback to base
            for candidate in ["galaxy-vision:1.0", "galaxy-vision:latest",
                               "qwen3-vl:4b-instruct", "qwen3-vl:latest"]:
                if any(candidate in n for n in names):
                    self._active_model = candidate
                    logger.info("Ollama backend: using model %s", candidate)
                    return candidate
            if names:
                self._active_model = names[0]
                return names[0]
        except Exception as e:
            logger.warning("Ollama model resolution failed: %s", e)
        self._active_model = "galaxy-vision:1.0"
        return self._active_model

    def generate(
        self,
        prompt: str,
        images_b64: Optional[List[str]] = None,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 40,
        max_tokens: int = 1024,
        stream: bool = False,
    ) -> Union[GenerationResponse, Generator[str, None, None]]:
        """Route single-turn generate calls through the multi-turn chat API."""
        messages = [{"role": "system", "content": _SYSTEM_PROMPT}]
        user_entry: Dict[str, Any] = {"role": "user", "content": prompt}
        if images_b64:
            user_entry["images"] = images_b64
        messages.append(user_entry)
        return self.chat(
            messages=messages,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            max_tokens=max_tokens,
            stream=stream,
        )

    def chat(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 40,
        max_tokens: int = 1024,
        stream: bool = False,
    ) -> Union[GenerationResponse, Generator[str, None, None]]:
        import httpx
        model = self._resolve_model()

        ollama_messages = []
        for m in messages:
            role = m.get("role", "user")
            content = m.get("content", "")
            if isinstance(content, list):
                text_parts = [p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text"]
                content = " ".join(text_parts) if text_parts else str(content)
            entry = {"role": role, "content": str(content)}
            if m.get("images"):
                entry["images"] = [_downscale_b64(b) for b in m["images"]]
            ollama_messages.append(entry)

        payload: Dict[str, Any] = {
            "model": model,
            "messages": ollama_messages,
            "stream": stream,
            "options": {
                "temperature": temperature,
                "top_p": top_p,
                "top_k": top_k,
                "num_predict": max_tokens,
            },
        }

        if stream:
            return self._stream_chat(payload)

        t0 = time.perf_counter()
        try:
            with httpx.Client(timeout=self.config.request_timeout) as c:
                resp = c.post(f"{self.host}/api/chat", json=payload)
                resp.raise_for_status()
                data = resp.json()
        except Exception as e:
            raise GalaxyVisionInferenceError(f"Ollama chat failed: {e}") from e

        wall = time.perf_counter() - t0
        msg_obj = data.get("message", {})
        return GenerationResponse(
            text=(msg_obj.get("content") or "").strip(),
            model=data.get("model", model),
            prompt_tokens=data.get("prompt_eval_count", 0),
            completion_tokens=data.get("eval_count", 0),
            total_duration_sec=data.get("total_duration", 0) / 1e9 or wall,
            load_duration_sec=data.get("load_duration", 0) / 1e9,
            eval_duration_sec=data.get("eval_duration", 0) / 1e9,
            finish_reason=data.get("done_reason", "stop"),
            raw=data,
        )

    def _stream_chat(self, payload: Dict) -> Generator[str, None, None]:
        import httpx, json as _json
        try:
            with httpx.Client(timeout=self.config.request_timeout) as c:
                with c.stream("POST", f"{self.host}/api/chat", json=payload) as resp:
                    resp.raise_for_status()
                    for line in resp.iter_lines():
                        if line:
                            d = _json.loads(line)
                            chunk = d.get("message", {}).get("content", "")
                            if chunk:
                                yield chunk
                            if d.get("done"):
                                break
        except Exception as e:
            raise GalaxyVisionInferenceError(f"Ollama stream chat failed: {e}") from e

    def _stream_gen(self, payload: Dict) -> Generator[str, None, None]:
        import httpx, json as _json
        try:
            with httpx.Client(timeout=self.config.request_timeout) as c:
                with c.stream("POST", f"{self.host}/api/generate", json=payload) as resp:
                    resp.raise_for_status()
                    for line in resp.iter_lines():
                        if line:
                            d = _json.loads(line)
                            chunk = d.get("response", "")
                            if chunk:
                                yield chunk
                            if d.get("done"):
                                break
        except Exception as e:
            raise GalaxyVisionInferenceError(f"Ollama stream failed: {e}") from e

    def health(self) -> Dict[str, Any]:
        ok = self.available()
        model = self._active_model or "galaxy-vision:1.0"
        return {
            "backend": "ollama",
            "ollama_reachable": ok,
            "active_model": model,
        }


# ══════════════════════════════════════════════════════════════════════════════
# BACKEND ROUTER — picks the best available backend automatically
# ══════════════════════════════════════════════════════════════════════════════

def _pick_backend(config: GalaxyVisionConfig):
    """Return the best available backend instance."""
    if _LlamaCppBackend.available(config):
        logger.info("Galaxy Vision: using llama-cpp-python backend (direct GGUF)")
        return _LlamaCppBackend(config)
    if _OllamaBackend.available():
        logger.info("Galaxy Vision: using Ollama HTTP backend (fallback)")
        return _OllamaBackend(config)
    raise GalaxyVisionInferenceError(
        "No inference backend available.\n"
        "Option 1 — Install llama-cpp-python:  pip install llama-cpp-python --prefer-binary\n"
        "Option 2 — Start Ollama daemon:       ollama serve"
    )


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API — GalaxyVision
# ══════════════════════════════════════════════════════════════════════════════

class GalaxyVision:
    """
    High-level Galaxy Vision interface — backend-agnostic.

    Example::

        from galaxy_vision import GalaxyVision
        gv = GalaxyVision()
        resp = gv.generate("What is the difference between RAM and VRAM?")
        print(resp.text)
    """

    def __init__(self, config: Optional[GalaxyVisionConfig] = None):
        self.config = config or get_config()
        self.model_name = self.config.model_name
        self._backend = _pick_backend(self.config)

    # ── text ──────────────────────────────────────────────────────────────────

    def generate(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **_,
    ) -> Union[GenerationResponse, Generator[str, None, None]]:
        return self._backend.generate(
            prompt=prompt,
            temperature=temperature if temperature is not None else self.config.temperature,
            top_p=top_p if top_p is not None else self.config.top_p,
            top_k=top_k if top_k is not None else self.config.top_k,
            max_tokens=max_tokens if max_tokens is not None else self.config.max_tokens,
            stream=stream,
        )

    def chat(
        self,
        messages: List[Dict[str, Any]],
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **_,
    ) -> Union[GenerationResponse, Generator[str, None, None]]:
        return self._backend.chat(
            messages=messages,
            temperature=temperature if temperature is not None else self.config.temperature,
            top_p=top_p if top_p is not None else self.config.top_p,
            top_k=top_k if top_k is not None else self.config.top_k,
            max_tokens=max_tokens if max_tokens is not None else self.config.max_tokens,
            stream=stream,
        )

    def chat_turn(
        self,
        conversation_id: str,
        message: str,
        images_b64: Optional[List[str]] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
    ) -> Tuple[Union[GenerationResponse, Generator[str, None, None]], Dict[str, Any]]:
        """Execute a context-aware conversation turn with entity and reference resolution."""
        from .context import get_context_manager
        mgr = get_context_manager()
        model_messages, analysis = mgr.build_model_messages(
            session_id=conversation_id,
            current_user_message=message,
            images_b64=images_b64,
        )
        resp = self.chat(
            messages=model_messages,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            max_tokens=max_tokens,
            stream=stream,
        )
        if not stream and isinstance(resp, GenerationResponse):
            mgr.register_turn(conversation_id, "user", message)
            mgr.register_turn(conversation_id, "assistant", resp.text)
        return resp, analysis

    # ── vision ────────────────────────────────────────────────────────────────

    def analyze_image(
        self,
        image_path: Union[str, bytes, Path],
        prompt: str = "Describe this image in detail.",
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **_,
    ) -> GenerationResponse:
        b64 = _to_b64(image_path)
        return self._backend.generate(
            prompt=prompt,
            images_b64=[b64],
            temperature=temperature if temperature is not None else self.config.temperature,
            top_p=top_p if top_p is not None else self.config.top_p,
            max_tokens=max_tokens if max_tokens is not None else self.config.max_tokens,
        )

    # ── video ─────────────────────────────────────────────────────────────────

    def analyze_video(
        self,
        video_path: Union[str, Path],
        prompt: str = "Summarise the key events in chronological order.",
        sample_interval_sec: float = 1.0,
        max_frames: int = 8,
        **_,
    ):
        from .video import VideoProcessor
        return VideoProcessor(self).analyze_video(
            video_path=str(video_path),
            prompt=prompt,
            sample_interval_sec=sample_interval_sec,
            max_frames=max_frames,
        )

    # ── document ──────────────────────────────────────────────────────────────

    def analyze_document(
        self,
        document_path: Union[str, bytes, Path],
        prompt: str = "Transcribe all text and extract structured information.",
        extract_tables: bool = True,
        return_json: bool = True,
        **_,
    ):
        from .document_processing import DocumentProcessor
        return DocumentProcessor(self).analyze(
            document_path=document_path,
            prompt=prompt,
            extract_tables=extract_tables,
            return_json=return_json,
        )

    # ── health ────────────────────────────────────────────────────────────────

    def health(self) -> Dict[str, Any]:
        sys_health = get_system_health()
        backend_health = self._backend.health()
        # Determine overall status
        if isinstance(self._backend, _LlamaCppBackend):
            ok = backend_health.get("gguf_found", False)
        else:
            ok = backend_health.get("ollama_reachable", False)
        return {
            "status": "healthy" if ok else "degraded",
            "target_model": self.model_name,
            **backend_health,
            **sys_health,
        }
