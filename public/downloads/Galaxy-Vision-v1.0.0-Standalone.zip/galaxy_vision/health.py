"""Health and resource diagnostics for Galaxy Vision — llama-cpp backend.

No Ollama dependency. Checks GGUF file presence, VRAM, and RAM.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

import psutil

try:
    import torch
    _TORCH = True
except ImportError:
    _TORCH = False

from .config import GalaxyVisionConfig, get_config

logger = logging.getLogger("galaxy_vision.health")


def check_gpu() -> Dict[str, Any]:
    """Inspect GPU hardware and VRAM utilization."""
    info: Dict[str, Any] = {"available": False, "device_count": 0, "devices": []}

    if _TORCH and torch.cuda.is_available():
        info["available"] = True
        info["device_count"] = torch.cuda.device_count()
        for i in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(i)
            free, total = (
                torch.cuda.mem_get_info(i)
                if hasattr(torch.cuda, "mem_get_info")
                else (0, props.total_memory)
            )
            info["devices"].append({
                "index": i,
                "name": props.name,
                "total_vram_mb": round(props.total_memory / 1_048_576, 1),
                "free_vram_mb": round(free / 1_048_576, 1),
                "used_vram_mb": round((total - free) / 1_048_576, 1),
                "compute_capability": f"{props.major}.{props.minor}",
            })
        return info

    # Fallback: nvidia-smi
    smi = shutil.which("nvidia-smi")
    if smi:
        try:
            res = subprocess.run(
                [smi, "--query-gpu=name,memory.total,memory.free,memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=5,
            )
            if res.returncode == 0:
                info["available"] = True
                for idx, line in enumerate(res.stdout.strip().splitlines()):
                    parts = [p.strip() for p in line.split(",")]
                    if len(parts) >= 4:
                        name, total_s, free_s, used_s = parts[:4]
                        info["devices"].append({
                            "index": idx, "name": name,
                            "total_vram_mb": float(total_s),
                            "free_vram_mb": float(free_s),
                            "used_vram_mb": float(used_s),
                            "source": "nvidia-smi",
                        })
                info["device_count"] = len(info["devices"])
        except Exception as err:
            logger.debug("nvidia-smi query failed: %s", err)

    return info


def check_system_ram() -> Dict[str, Any]:
    """Inspect host RAM metrics."""
    vm = psutil.virtual_memory()
    return {
        "total_ram_mb": round(vm.total / 1_048_576, 1),
        "available_ram_mb": round(vm.available / 1_048_576, 1),
        "used_ram_mb": round(vm.used / 1_048_576, 1),
        "percent_used": vm.percent,
    }


def check_gguf_status(config: Optional[GalaxyVisionConfig] = None) -> Dict[str, Any]:
    """Check whether the GGUF model file is present and report its size."""
    cfg = config or get_config()
    gguf = Path(cfg.gguf_path)
    exists = gguf.is_file()
    size_mb = round(gguf.stat().st_size / 1_048_576, 1) if exists else 0.0
    return {
        "gguf_found": exists,
        "gguf_path": str(gguf),
        "gguf_size_mb": size_mb,
    }


def get_system_health(config: Optional[GalaxyVisionConfig] = None) -> Dict[str, Any]:
    """Aggregate full health diagnostics for Galaxy Vision."""
    cfg = config or get_config()
    gguf_stat = check_gguf_status(cfg)
    ram_stat = check_system_ram()
    gpu_stat = check_gpu()

    overall = "healthy" if gguf_stat["gguf_found"] else "degraded"

    return {
        "status": overall,
        "product": cfg.product_name,
        "version": cfg.version,
        "target_model": cfg.model_name,
        "backend": "llama-cpp-python",
        "ollama": {"available": False, "note": "Direct GGUF inference — Ollama interface not used"},
        "system_ram": ram_stat,
        "gpu": gpu_stat,
        **gguf_stat,
    }
