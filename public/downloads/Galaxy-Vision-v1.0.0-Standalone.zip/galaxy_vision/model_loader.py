"""Model loader for Galaxy Vision — llama-cpp-python backend.

Locates the GGUF file, validates it, and provides model metadata.
No Ollama, no HTTP daemon required.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from .config import GalaxyVisionConfig, get_config

logger = logging.getLogger("galaxy_vision.model_loader")


@dataclass
class ModelInfo:
    """Metadata describing the active model instance."""
    name: str
    backend: str = "llama-cpp"
    architecture: str = "galaxy-vl"
    parameter_count: str = "4.4B"
    quantization: str = "Q4_K_M"
    context_length: int = 8192
    capabilities: List[str] = field(default_factory=list)
    is_customized: bool = True
    gguf_path: str = ""

    def __post_init__(self):
        if not self.capabilities:
            self.capabilities = [
                "text-generation",
                "vision",
                "ocr",
                "visual-reasoning",
                "document-analysis",
                "video-frames",
            ]


class ModelLoader:
    """Validates that the GGUF file exists and returns model metadata."""

    def __init__(self, config: Optional[GalaxyVisionConfig] = None):
        self.config = config or get_config()

    def verify_model(self) -> str:
        """Check the GGUF path and return it; raise if missing."""
        gguf = Path(self.config.gguf_path)
        if not gguf.is_file():
            raise FileNotFoundError(
                f"Galaxy Vision GGUF model not found at:\n  {gguf}\n\n"
                "Options:\n"
                "  1. Set GALAXY_GGUF_PATH environment variable to your .gguf file path.\n"
                "  2. Place the model file at the default location above.\n"
                "  3. Run setup.bat to configure automatically."
            )
        size_mb = gguf.stat().st_size / 1_048_576
        logger.info("Galaxy Vision GGUF found: %s (%.1f MB)", gguf, size_mb)
        return str(gguf)

    def get_model_info(self) -> ModelInfo:
        """Return static model metadata."""
        gguf_path = self.config.gguf_path
        size_mb = 0.0
        try:
            size_mb = Path(gguf_path).stat().st_size / 1_048_576
        except OSError:
            pass

        return ModelInfo(
            name=self.config.model_name,
            backend="llama-cpp",
            architecture="galaxy-vl",
            parameter_count="4.4B",
            quantization="Q4_K_M",
            context_length=self.config.context_length,
            is_customized=True,
            gguf_path=gguf_path,
        )
