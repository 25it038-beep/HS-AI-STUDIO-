"""Video processing and temporal reasoning subsystem for Galaxy Vision.

Implements an efficient frame extraction, timestamp-indexed visual sampling,
and chronological synthesis pipeline using OpenCV.
"""

from __future__ import annotations

import base64
import io
import logging
import os
import shutil
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

import cv2
from PIL import Image

if TYPE_CHECKING:
    from .config import GalaxyVisionConfig
    from .inference import GalaxyVision

logger = logging.getLogger("galaxy_vision.video")

SUPPORTED_VIDEO_FORMATS = {".mp4", ".avi", ".mov", ".mkv", ".webm"}


@dataclass
class VideoFrame:
    """Individual sampled video frame with exact temporal metadata."""
    frame_index: int
    timestamp_sec: float
    timestamp_formatted: str
    image_bytes: bytes


@dataclass
class VideoAnalysisResult:
    """Result of chronological video processing and analysis."""
    text: str
    model: str
    video_path: str
    duration_sec: float
    total_frames_in_video: int
    sampled_frames_count: int
    sample_interval_sec: float
    fps: float
    frame_timestamps: List[float]
    is_native_video_stream: bool = False
    limitations: str = (
        "Video understanding is achieved via chronological discrete frame extraction and visual synthesis. "
        "High-frequency motion, fine audio cues, and sub-second transient actions between sampled frames "
        "may not be captured."
    )
    latency_sec: float = 0.0
    raw: Dict[str, Any] = field(default_factory=dict)


def format_timestamp(seconds: float) -> str:
    """Format seconds into HH:MM:SS.mmm format."""
    hrs = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    secs = seconds % 60
    return f"{hrs:02d}:{mins:02d}:{secs:06.3f}"


class VideoProcessor:
    """Extracts, filters, and analyzes video sequences for multimodal understanding."""

    def __init__(self, engine: "GalaxyVision", config: Optional["GalaxyVisionConfig"] = None):
        self.engine = engine
        self.config = config or engine.config

    def extract_frames(
        self,
        video_path: Union[str, Path],
        sample_interval_sec: float = 1.0,
        max_frames: int = 16,
        target_resolution: Tuple[int, int] = (640, 480)
    ) -> Tuple[List[VideoFrame], Dict[str, Any]]:
        """Sequentially sample frames from video file using OpenCV, keeping memory footprint low."""
        path = Path(video_path)
        if not path.is_file():
            raise FileNotFoundError(f"Video file not found at: {path}")

        ext = path.suffix.lower()
        if ext not in SUPPORTED_VIDEO_FORMATS:
            logger.warning("Uncommon video extension '%s'; attempting to read anyway.", ext)

        cap = cv2.VideoCapture(str(path))
        if not cap.isOpened():
            raise ValueError(f"Failed to open video file '{path}'. Ensure codec is supported.")

        try:
            fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            duration_sec = total_frames / fps if fps > 0 else 0.0

            frames: List[VideoFrame] = []
            frame_step = max(1, int(round(fps * sample_interval_sec)))
            current_frame_idx = 0

            while cap.isOpened() and len(frames) < max_frames:
                cap.set(cv2.CAP_PROP_POS_FRAMES, current_frame_idx)
                ret, frame = cap.read()
                if not ret:
                    break

                timestamp = current_frame_idx / fps
                
                # Resize frame to target resolution to optimize inference latency and VRAM
                h, w = frame.shape[:2]
                if w > target_resolution[0] or h > target_resolution[1]:
                    frame = cv2.resize(frame, target_resolution, interpolation=cv2.INTER_AREA)

                # Convert BGR (OpenCV) to RGB (Pillow) and encode as JPEG
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                pil_img = Image.fromarray(rgb_frame)
                buf = io.BytesIO()
                pil_img.save(buf, format="JPEG", quality=85)
                img_bytes = buf.getvalue()

                frames.append(VideoFrame(
                    frame_index=current_frame_idx,
                    timestamp_sec=round(timestamp, 3),
                    timestamp_formatted=format_timestamp(timestamp),
                    image_bytes=img_bytes
                ))

                current_frame_idx += frame_step
                if current_frame_idx >= total_frames:
                    break

            metadata = {
                "fps": round(fps, 2),
                "total_frames": total_frames,
                "duration_sec": round(duration_sec, 2),
                "sample_interval_sec": sample_interval_sec
            }
            return frames, metadata

        finally:
            cap.release()

    def analyze_video(
        self,
        video_path: Union[str, Path],
        prompt: str = "Provide a chronological narrative of the events in this video.",
        sample_interval_sec: Optional[float] = None,
        max_frames: Optional[int] = None,
        **kwargs
    ) -> VideoAnalysisResult:
        """Extract frames and synthesize a timestamp-aware chronological analysis."""
        start_time = time.perf_counter()
        interval = sample_interval_sec or self.config.video_sample_interval_sec
        limit = max_frames or self.config.max_video_frames

        frames, meta = self.extract_frames(
            video_path=video_path,
            sample_interval_sec=interval,
            max_frames=limit
        )

        if not frames:
            raise ValueError(f"No frames could be extracted from video '{video_path}'.")

        logger.info(
            "Extracted %d frames from '%s' (duration: %.1fs, interval: %.1fs)",
            len(frames), video_path, meta["duration_sec"], interval
        )

        # Convert sampled frames to base64
        base64_frames = [base64.b64encode(f.image_bytes).decode("utf-8") for f in frames]
        frame_timestamps = [f.timestamp_sec for f in frames]
        timestamps_legend = ", ".join([f"Frame {idx+1} ({f.timestamp_formatted})" for idx, f in enumerate(frames)])

        enhanced_prompt = (
            f"You are analyzing a video sequence composed of {len(frames)} chronologically ordered frames.\n"
            f"Sampling intervals: {timestamps_legend}.\n\n"
            f"User Query: {prompt}\n\n"
            "Guidelines:\n"
            "- Describe the progression of events in chronological sequence.\n"
            "- Reference exact timestamps where noteworthy actions or transitions occur.\n"
            "- Note any visual changes between earlier and later frames.\n"
            "- Clearly acknowledge that this analysis is synthesized from discrete sampled keyframes."
        )

        # Analyze each frame individually then synthesize
        frame_analyses = []
        for idx, frame in enumerate(frames):
            frame_prompt = (
                f"Frame {idx+1} at {frame.timestamp_formatted}: "
                f"Describe what is visible in this frame. {prompt if idx == 0 else 'Continue the visual analysis.'}"
            )
            try:
                resp = self.engine.analyze_image(
                    image_path=frame.image_bytes,
                    prompt=frame_prompt,
                    max_tokens=self.config.max_tokens // max(1, len(frames)),
                )
                frame_analyses.append(f"[{frame.timestamp_formatted}] {resp.text}")
            except Exception as exc:
                logger.warning("Frame %d analysis failed: %s", idx + 1, exc)
                frame_analyses.append(f"[{frame.timestamp_formatted}] (frame analysis unavailable)")

        combined_text = "\n\n".join(frame_analyses)

        # Synthesize a cohesive narrative
        synthesis_prompt = (
            f"You are given chronological frame-by-frame analysis of a video ({len(frames)} sampled frames).\n"
            f"Timestamps: {timestamps_legend}\n\n"
            f"Frame analyses:\n{combined_text}\n\n"
            f"User Query: {prompt}\n\n"
            "Write a coherent, chronological narrative synthesizing all the above frame observations. "
            "Reference timestamps where relevant. Acknowledge this is a discrete frame-sampled analysis."
        )

        try:
            synthesis_resp = self.engine.generate(prompt=synthesis_prompt)
            final_text = synthesis_resp.text
            final_model = synthesis_resp.model
            raw = synthesis_resp.raw
        except Exception as exc:
            logger.warning("Synthesis failed, using frame concatenation: %s", exc)
            final_text = combined_text
            final_model = self.engine.model_name
            raw = {}

        latency = time.perf_counter() - start_time

        return VideoAnalysisResult(
            text=final_text,
            model=final_model,
            video_path=str(video_path),
            duration_sec=meta["duration_sec"],
            total_frames_in_video=meta["total_frames"],
            sampled_frames_count=len(frames),
            sample_interval_sec=interval,
            fps=meta["fps"],
            frame_timestamps=frame_timestamps,
            latency_sec=round(latency, 2),
            raw=raw
        )
