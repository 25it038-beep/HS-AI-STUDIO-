"""Web search and AI-grounded answer synthesis module for Galaxy Vision.

Performs real-time web searches using DuckDuckGo (no API key required),
retrieves result snippets, then passes structured context to Galaxy Vision
to generate a grounded, cited response.
"""

from __future__ import annotations

import html
import logging
import re
import time
import urllib.parse
import warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import httpx

warnings.filterwarnings("ignore", category=RuntimeWarning, message=".*duckduckgo_search.*")

if TYPE_CHECKING:
    from .inference import GalaxyVision

# Import DDGS at module level so it can be patched in tests
try:
    from duckduckgo_search import DDGS
except ImportError:
    DDGS = None  # type: ignore[assignment,misc]

logger = logging.getLogger("galaxy_vision.websearch")


@dataclass
class SearchResult:
    """Single DuckDuckGo search result item."""
    title: str
    url: str
    snippet: str


@dataclass
class WebSearchResponse:
    """Combined search + AI synthesis response."""
    query: str
    search_results: List[SearchResult]
    answer: str
    model: str
    num_results_used: int
    latency_sec: float = 0.0
    sources: List[Dict[str, str]] = field(default_factory=list)


def _scrape_ddg_lite(query: str, max_results: int = 6) -> List[SearchResult]:
    """Fast, reliable web search using DuckDuckGo Lite endpoint via httpx."""
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    try:
        with httpx.Client(headers=headers, timeout=10.0, follow_redirects=True) as client:
            resp = client.post("https://lite.duckduckgo.com/lite/", data={"q": query})
            if resp.status_code != 200:
                logger.debug("DuckDuckGo Lite returned status %d", resp.status_code)
                return []

            text = resp.text
            a_tags = re.findall(
                r'<a\s+([^>]*class=[\'"]result-link[\'"][^>]*)>([\s\S]*?)</a>', text
            )
            snippets = re.findall(
                r'<td\s+[^>]*class=[\'"]result-snippet[\'"][^>]*>([\s\S]*?)</td>', text
            )

            results: List[SearchResult] = []
            for i in range(min(len(a_tags), max_results)):
                attrs, raw_title = a_tags[i]
                href_m = re.search(r'href=[\'"]([^\'"]+)[\'"]', attrs)
                if not href_m:
                    continue
                url = href_m.group(1)
                if "uddg=" in url:
                    qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                    url = qs.get("uddg", [url])[0]

                clean_title = html.unescape(re.sub(r"<[^>]+>", "", raw_title)).strip()
                clean_snippet = (
                    html.unescape(re.sub(r"<[^>]+>", "", snippets[i])).strip()
                    if i < len(snippets)
                    else ""
                )

                if clean_title and url:
                    results.append(
                        SearchResult(title=clean_title, url=url, snippet=clean_snippet)
                    )
            return results
    except Exception as exc:
        logger.debug("DuckDuckGo Lite search failed: %s", exc)
        return []


def _search_wikipedia(query: str, max_results: int = 4) -> List[SearchResult]:
    """Fallback search using Wikipedia OpenSearch API."""
    headers = {"User-Agent": "GalaxyVision/1.0 (https://hs-ai-studio-4i7i.vercel.app/)"}
    try:
        with httpx.Client(headers=headers, timeout=8.0) as client:
            resp = client.get(
                "https://en.wikipedia.org/w/api.php",
                params={
                    "action": "query",
                    "list": "search",
                    "srsearch": query,
                    "format": "json",
                    "utf8": 1,
                    "srlimit": max_results,
                },
            )
            if resp.status_code != 200:
                return []
            data = resp.json()
            items = data.get("query", {}).get("search", [])
            results: List[SearchResult] = []
            for it in items:
                title = it.get("title", "")
                snippet = html.unescape(re.sub(r"<[^>]+>", "", it.get("snippet", ""))).strip()
                url = f"https://en.wikipedia.org/wiki/{urllib.parse.quote(title.replace(' ', '_'))}"
                results.append(SearchResult(title=title, url=url, snippet=snippet))
            return results
    except Exception as exc:
        logger.debug("Wikipedia search failed: %s", exc)
        return []


def search_web(query: str, max_results: int = 6) -> List[SearchResult]:
    """Perform a web search and return structured results with automated fallbacks."""
    results: List[SearchResult] = []

    # Strategy 1: Try DDGS library if present (honored by mocked unit tests)
    if DDGS is not None:
        try:
            with DDGS() as ddgs:
                for r in ddgs.text(query, max_results=max_results, safesearch="moderate"):
                    results.append(
                        SearchResult(
                            title=r.get("title", ""),
                            url=r.get("href", ""),
                            snippet=r.get("body", ""),
                        )
                    )
            if results:
                logger.info("DDGS library returned %d results for '%s'", len(results), query)
                return results
        except Exception as exc:
            logger.debug("DDGS library search failed: %s. Falling back to direct HTTP.", exc)

    # Strategy 2: Fast & reliable DuckDuckGo Lite endpoint
    results = _scrape_ddg_lite(query, max_results=max_results)
    if results:
        logger.info("DuckDuckGo Lite returned %d results for '%s'", len(results), query)
        return results

    # Strategy 3: Wikipedia API fallback
    results = _search_wikipedia(query, max_results=min(max_results, 4))
    if results:
        logger.info("Wikipedia search returned %d results for '%s'", len(results), query)
        return results

    return []


def build_search_context(query: str, results: List[SearchResult]) -> str:
    """Format search snippets into a grounded context block for the model."""
    if not results:
        return f"No web results were found for: '{query}'"

    lines = [f'Web Search Results for: "{query}"\n']
    for idx, r in enumerate(results, 1):
        lines.append(f"[Source {idx}] {r.title}")
        lines.append(f"URL: {r.url}")
        lines.append(f"Excerpt: {r.snippet}")
        lines.append("")
    return "\n".join(lines)


class WebSearchEngine:
    """Combines real-time web search with Galaxy Vision AI synthesis."""

    def __init__(self, engine: "GalaxyVision"):
        self.engine = engine

    def search_and_answer(
        self,
        query: str,
        max_results: int = 6,
        synthesis_prompt: Optional[str] = None,
        **kwargs,
    ) -> WebSearchResponse:
        """1. Search the web for the query.

        2. Collect result titles, URLs, and snippets. 3. Synthesize a grounded,
        cited answer using Galaxy Vision.
        """
        start_t = time.perf_counter()

        try:
            results = search_web(query, max_results=max_results)
        except Exception as exc:
            logger.warning("Search encountered error, falling back gracefully: %s", exc)
            results = []

        if not results:
            # Fallback to model generation with a note rather than failing
            prompt = (
                f'The user is asking: "{query}"\n\n'
                "Please provide a comprehensive and helpful answer to this question based on your foundation knowledge. "
                "Note to the user that live web search results were currently unavailable for this specific query."
            )
            resp = self.engine.generate(prompt=prompt, **kwargs)
            latency = time.perf_counter() - start_t
            return WebSearchResponse(
                query=query,
                search_results=[],
                answer=resp.text,
                model=resp.model,
                num_results_used=0,
                latency_sec=round(latency, 2),
                sources=[],
            )

        context_block = build_search_context(query, results)

        prompt = synthesis_prompt or (
            f'You have access to the following real-time web search results for the query: "{query}"\n\n'
            f"{context_block}\n\n"
            f'Using the information from these search results, provide a comprehensive, accurate, and well-organized answer to: "{query}"\n'
            "- Cite the source number (e.g., [Source 1]) whenever you reference a specific fact.\n"
            "- Clearly structure the response with clear headings or bullet points.\n"
            "- If certain details cannot be determined from the provided results, explain clearly."
        )

        resp = self.engine.generate(prompt=prompt, **kwargs)
        latency = time.perf_counter() - start_t

        sources = [{"title": r.title, "url": r.url} for r in results]

        return WebSearchResponse(
            query=query,
            search_results=results,
            answer=resp.text,
            model=resp.model,
            num_results_used=len(results),
            latency_sec=round(latency, 2),
            sources=sources,
        )
