"""Conversational Context Management & Multi-turn Dialogue Engine.

Provides:
- Persistent conversation context & storage (Level B memory)
- Pronoun & relational reference resolution (he, she, they, his father, etc.)
- Multi-entity tracking & focus management
- Context window budgeting & intelligent summarization
- Long-term memory profile (Level C memory)
- Conversation isolation and switching
"""

from __future__ import annotations

import json
import logging
import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("galaxy_vision.context")

# ══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Message:
    role: str  # "user", "assistant", "system"
    content: str
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Message":
        return cls(
            role=data.get("role", "user"),
            content=data.get("content", ""),
            id=data.get("id", str(uuid.uuid4())[:8]),
            timestamp=data.get("timestamp", time.time()),
            metadata=data.get("metadata", {}),
        )


@dataclass
class Entity:
    name: str
    entity_type: str = "person"  # "person", "place", "concept", "organization", "relation"
    aliases: List[str] = field(default_factory=list)
    attributes: Dict[str, str] = field(default_factory=dict)
    relations: Dict[str, str] = field(default_factory=dict)  # e.g. {"father": "M. Karunanidhi"}
    gender: Optional[str] = None  # "male", "female", "neutral"
    last_mentioned_turn: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Entity":
        return cls(
            name=data.get("name", ""),
            entity_type=data.get("entity_type", "person"),
            aliases=data.get("aliases", []),
            attributes=data.get("attributes", {}),
            relations=data.get("relations", {}),
            gender=data.get("gender"),
            last_mentioned_turn=data.get("last_mentioned_turn", 0),
        )


@dataclass
class ConversationSession:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = "New Conversation"
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    messages: List[Message] = field(default_factory=list)
    entities: Dict[str, Entity] = field(default_factory=dict)
    summary: str = ""
    active_focus_entity: Optional[str] = None
    previous_focus_entity: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "messages": [m.to_dict() for m in self.messages],
            "entities": {k: v.to_dict() for k, v in self.entities.items()},
            "summary": self.summary,
            "active_focus_entity": self.active_focus_entity,
            "previous_focus_entity": self.previous_focus_entity,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConversationSession":
        session = cls(
            id=data.get("id", str(uuid.uuid4())),
            title=data.get("title", "New Conversation"),
            created_at=data.get("created_at", time.time()),
            updated_at=data.get("updated_at", time.time()),
            summary=data.get("summary", ""),
            active_focus_entity=data.get("active_focus_entity"),
            previous_focus_entity=data.get("previous_focus_entity"),
            metadata=data.get("metadata", {}),
        )
        session.messages = [Message.from_dict(m) for m in data.get("messages", [])]
        session.entities = {
            k: Entity.from_dict(v) for k, v in data.get("entities", {}).items()
        }
        return session


# ══════════════════════════════════════════════════════════════════════════════
# REFERENCE & PRONOUN RESOLUTION
# ══════════════════════════════════════════════════════════════════════════════

# Common pronoun and relational patterns
_MALE_PRONOUNS = {"he", "him", "his", "himself"}
_FEMALE_PRONOUNS = {"she", "her", "hers", "herself"}
_PLURAL_PRONOUNS = {"they", "them", "their", "theirs", "themselves"}
_THING_PRONOUNS = {"it", "its", "itself", "this", "that", "these", "those"}

# Relational patterns: "his father", "her husband", "their company", etc.
_RELATION_PATTERNS = [
    (re.compile(r"\b(?:his|her|their)\s+(father|mother|dad|mom|parents)\b", re.I), "father/mother"),
    (re.compile(r"\b(?:his|her|their)\s+(son|daughter|child|children|kids)\b", re.I), "child"),
    (re.compile(r"\b(?:his|her|their)\s+(wife|husband|spouse|partner)\b", re.I), "spouse"),
    (re.compile(r"\b(?:his|her|their)\s+(family|background|dynasty)\b", re.I), "family"),
    (re.compile(r"\b(?:his|her|their)\s+(brother|sister|sibling)\b", re.I), "sibling"),
    (re.compile(r"\b(?:his|her|their)\s+(party|government|career|company|work)\b", re.I), "career/organization"),
    (re.compile(r"\b(?:what|how)\s+about\s+(?:his|her|their)\s+([a-zA-Z\s]+)\b", re.I), "relation_query"),
    (re.compile(r"\b(?:the\s+)?(previous\s+person|former|latter|second\s+option|first\s+option)\b", re.I), "positional"),
]


class ReferenceResolver:
    """Detects and resolves pronouns and relational references in user inputs."""

    @staticmethod
    def analyze_query(query: str, session: ConversationSession) -> Dict[str, Any]:
        """
        Analyze a user query for pronouns, anaphora, and relational references.
        Returns resolution metadata and grounded context suggestions.
        """
        words = set(re.findall(r"\b[a-zA-Z]+\b", query.lower()))
        tokens = query.strip()

        has_male_pronoun = bool(words & _MALE_PRONOUNS)
        has_female_pronoun = bool(words & _FEMALE_PRONOUNS)
        has_plural_pronoun = bool(words & _PLURAL_PRONOUNS)
        has_thing_pronoun = bool(words & _THING_PRONOUNS)

        detected_relations = []
        for pat, rel_type in _RELATION_PATTERNS:
            m = pat.search(tokens)
            if m:
                detected_relations.append((m.group(0), rel_type, m.groups()[-1] if m.groups() else ""))

        # Check for short follow-up patterns
        is_short_followup = len(tokens.split()) <= 7 and (
            has_male_pronoun or has_female_pronoun or has_plural_pronoun or
            has_thing_pronoun or bool(detected_relations) or
            tokens.lower().startswith(("is he", "is she", "was he", "was she", "what about", "tell me more", "how about", "where does", "what happened"))
        )

        resolved_subject = None
        resolved_context_note = ""
        is_ambiguous = False
        target_entity: Optional[Entity] = None

        # Look up current active focus
        if session.active_focus_entity and session.active_focus_entity in session.entities:
            target_entity = session.entities[session.active_focus_entity]

        # 1. Relational references like "his father", "what about his father?"
        if detected_relations and target_entity:
            for phrase, rel_type, rel_name in detected_relations:
                rel_key = rel_name.strip().lower()
                # Check if target entity has known relation
                known_val = target_entity.relations.get(rel_key)
                if known_val:
                    resolved_subject = known_val
                    resolved_context_note = f"Reference '{phrase}' resolves to {known_val} ({rel_key} of {target_entity.name})."
                else:
                    resolved_subject = f"{rel_key} of {target_entity.name}"
                    resolved_context_note = f"Reference '{phrase}' resolves to the {rel_key} of {target_entity.name}."

        # 2. Pronouns ("he", "him", "his", "she", "her", "tell me more about him")
        elif (has_male_pronoun or has_female_pronoun) and target_entity:
            # Check gender compatibility
            if has_male_pronoun and target_entity.gender == "female":
                # Check if there is another male entity in session
                male_candidates = [e for e in session.entities.values() if e.gender == "male"]
                if len(male_candidates) == 1:
                    target_entity = male_candidates[0]
                    resolved_subject = target_entity.name
                    resolved_context_note = f"Male pronoun resolved to {target_entity.name}."
                elif len(male_candidates) > 1:
                    is_ambiguous = True
                else:
                    resolved_subject = target_entity.name
                    resolved_context_note = f"Pronoun resolved to active focus {target_entity.name}."
            elif has_female_pronoun and target_entity.gender == "male":
                female_candidates = [e for e in session.entities.values() if e.gender == "female"]
                if len(female_candidates) == 1:
                    target_entity = female_candidates[0]
                    resolved_subject = target_entity.name
                    resolved_context_note = f"Female pronoun resolved to {target_entity.name}."
                elif len(female_candidates) > 1:
                    is_ambiguous = True
                else:
                    resolved_subject = target_entity.name
                    resolved_context_note = f"Pronoun resolved to active focus {target_entity.name}."
            else:
                resolved_subject = target_entity.name
                resolved_context_note = f"Pronoun refers to active conversation subject: {target_entity.name}."

        # 3. Thing pronouns ("it", "that place", "that")
        elif has_thing_pronoun and not (has_male_pronoun or has_female_pronoun):
            # Find non-person entities or active entity
            places_concepts = [
                e for e in session.entities.values()
                if e.entity_type in ("place", "concept", "organization")
            ]
            if places_concepts:
                latest_p = max(places_concepts, key=lambda x: x.last_mentioned_turn)
                resolved_subject = latest_p.name
                resolved_context_note = f"Reference '{tokens}' refers to {latest_p.name} ({latest_p.entity_type})."
            elif target_entity:
                resolved_subject = target_entity.name
                resolved_context_note = f"Reference refers to {target_entity.name}."

        # 4. Check for positional references ("the previous person", "the second option")
        for phrase, rel_type, _ in detected_relations:
            if rel_type == "positional":
                if "previous" in phrase.lower() and session.previous_focus_entity:
                    resolved_subject = session.previous_focus_entity
                    resolved_context_note = f"Positional reference resolves to previous person: {session.previous_focus_entity}."

        return {
            "has_male_pronoun": has_male_pronoun,
            "has_female_pronoun": has_female_pronoun,
            "has_plural_pronoun": has_plural_pronoun,
            "has_thing_pronoun": has_thing_pronoun,
            "is_short_followup": is_short_followup,
            "detected_relations": detected_relations,
            "resolved_subject": resolved_subject,
            "resolved_context_note": resolved_context_note,
            "is_ambiguous": is_ambiguous,
            "active_focus": session.active_focus_entity,
        }

    @staticmethod
    def extract_entities_from_text(text: str, role: str, turn_idx: int) -> List[Entity]:
        """
        Heuristic extraction of key named entities (people, roles, relations)
        from message content to build conversation memory.
        """
        extracted = []

        # Known political / historical / public entities heuristic patterns
        # e.g., "M. K. Stalin", "M. Karunanidhi", "Tamil Nadu", "DMK", etc.
        patterns = [
            # Initials + Name: "M. K. Stalin", "C. N. Annadurai", "M. G. Ramachandran"
            r"\b[A-Z]\.\s*[A-Z]?\.\s*[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b",
            # Standard capitalized names: "M.K. Stalin", "Karunanidhi", "Udhayanidhi Stalin"
            r"\b(?:M\.K\.\s*Stalin|M\.\s*K\.\s*Stalin|Karunanidhi|M\.\s*Karunanidhi|Muthuvel Karunanidhi Stalin)\b",
            # State/Role pairs: "Chief Minister of Tamil Nadu", "Prime Minister of India"
            r"\b(?:Chief Minister of\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b",
            r"\b(?:Tamil Nadu|DMK|AIADMK)\b",
        ]

        # Scan text for prominent capitalized entity mentions
        for p in patterns:
            for match in re.finditer(p, text, re.IGNORECASE):
                val = match.group(0).strip()
                if len(val) >= 3:
                    # Clean punctuation
                    name = re.sub(r"\s+", " ", val)
                    gender = "male" if any(w in name.lower() for w in ["stalin", "karunanidhi", "kumar", "singh", "sharma"]) else None
                    e_type = "place" if "tamil nadu" in name.lower() else "person"
                    extracted.append(Entity(
                        name=name,
                        entity_type=e_type,
                        gender=gender,
                        last_mentioned_turn=turn_idx
                    ))

        # Check for relation definitions: "father is M. Karunanidhi", "son of M. Karunanidhi"
        father_match = re.search(r"(?:father(?:\s+is|\s+was)?|son\s+of)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*|M\.\s*K\.\s*[A-Z][a-z]+|M\.\s*Karunanidhi|Karunanidhi)", text, re.I)
        if father_match:
            f_name = father_match.group(1).strip()
            extracted.append(Entity(
                name=f_name,
                entity_type="person",
                gender="male",
                relations={"child": "M. K. Stalin"},
                last_mentioned_turn=turn_idx
            ))

        return extracted


# ══════════════════════════════════════════════════════════════════════════════
# CONTEXT MANAGER (Memory Levels A, B, C & Token Budgeting)
# ══════════════════════════════════════════════════════════════════════════════

class ContextManager:
    """
    Manages multi-turn conversation context across three tiers:
    - Level A: Current-turn context & immediate sliding window
    - Level B: In-conversation entity, facts, and running summary store
    - Level C: Long-term persistent memory across sessions
    """

    def __init__(self, data_dir: Optional[Path] = None, max_context_tokens: int = 3500, max_recent_turns: int = 6):
        self.data_dir = data_dir or (Path(__file__).parent.parent / "data")
        self.conv_dir = self.data_dir / "conversations"
        self.memory_file = self.data_dir / "memory" / "long_term_memory.json"
        self.max_context_tokens = max_context_tokens
        self.max_recent_turns = max_recent_turns

        # Ensure directory structures exist
        self.conv_dir.mkdir(parents=True, exist_ok=True)
        self.memory_file.parent.mkdir(parents=True, exist_ok=True)

        self._active_sessions: Dict[str, ConversationSession] = {}
        self._load_long_term_memory()

    # ── Level C: Long-Term Memory ─────────────────────────────────────────────

    def _load_long_term_memory(self):
        self.long_term_memory: Dict[str, Any] = {
            "user_profile": {},
            "persistent_facts": [],
            "preferences": {"language": "en", "detail_level": "detailed"}
        }
        if self.memory_file.is_file():
            try:
                self.long_term_memory = json.loads(self.memory_file.read_text(encoding="utf-8"))
            except Exception as e:
                logger.warning("Failed to load long-term memory: %s", e)

    def save_long_term_memory(self):
        try:
            self.memory_file.write_text(json.dumps(self.long_term_memory, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error("Failed to save long-term memory: %s", e)

    def update_long_term_fact(self, fact: str):
        if fact and fact not in self.long_term_memory.get("persistent_facts", []):
            self.long_term_memory.setdefault("persistent_facts", []).append(fact)
            self.save_long_term_memory()

    def clear_long_term_memory(self):
        self.long_term_memory = {"user_profile": {}, "persistent_facts": [], "preferences": {}}
        self.save_long_term_memory()

    # ── Level B: Conversation Storage & Sessions ──────────────────────────────

    def get_or_create_session(self, session_id: Optional[str] = None) -> ConversationSession:
        """Retrieve existing session from cache/disk or instantiate a fresh one."""
        if not session_id:
            new_session = ConversationSession()
            self._active_sessions[new_session.id] = new_session
            self.save_session(new_session)
            return new_session

        if session_id in self._active_sessions:
            return self._active_sessions[session_id]

        file_path = self.conv_dir / f"{session_id}.json"
        if file_path.is_file():
            try:
                data = json.loads(file_path.read_text(encoding="utf-8"))
                session = ConversationSession.from_dict(data)
                self._active_sessions[session.id] = session
                return session
            except Exception as e:
                logger.error("Failed loading session %s: %e", session_id, e)

        # Fallback create with given id
        session = ConversationSession(id=session_id)
        self._active_sessions[session.id] = session
        self.save_session(session)
        return session

    def save_session(self, session: ConversationSession):
        """Persist session state to disk."""
        session.updated_at = time.time()
        file_path = self.conv_dir / f"{session.id}.json"
        try:
            file_path.write_text(json.dumps(session.to_dict(), indent=2), encoding="utf-8")
        except Exception as e:
            logger.error("Failed saving session %s: %s", session.id, e)

    def list_sessions(self) -> List[Dict[str, Any]]:
        """List all saved conversations sorted by most recently updated."""
        sessions = []
        for p in self.conv_dir.glob("*.json"):
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                sessions.append({
                    "id": d.get("id", p.stem),
                    "title": d.get("title", "Conversation"),
                    "created_at": d.get("created_at", 0),
                    "updated_at": d.get("updated_at", 0),
                    "message_count": len(d.get("messages", [])),
                    "active_focus": d.get("active_focus_entity"),
                })
            except Exception:
                continue
        sessions.sort(key=lambda s: s["updated_at"], reverse=True)
        return sessions

    def delete_session(self, session_id: str) -> bool:
        """Delete a conversation session file and remove from memory."""
        self._active_sessions.pop(session_id, None)
        file_path = self.conv_dir / f"{session_id}.json"
        if file_path.is_file():
            try:
                file_path.unlink()
                return True
            except Exception as e:
                logger.error("Failed deleting session %s: %s", session_id, e)
        return False

    def clear_all_sessions(self) -> int:
        """Delete all saved conversations."""
        count = 0
        self._active_sessions.clear()
        for p in self.conv_dir.glob("*.json"):
            try:
                p.unlink()
                count += 1
            except Exception:
                pass
        return count

    # ── Level A & B: Turn Processing, Entity Updates & Dialogue History ──────

    def register_turn(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Message:
        """
        Record a user or assistant turn, update entities, relations,
        and active focus entity.
        """
        session = self.get_or_create_session(session_id)
        msg = Message(role=role, content=content, metadata=metadata or {})
        session.messages.append(msg)
        turn_idx = len(session.messages)

        # Update conversation title from first user message if default
        if role == "user" and session.title == "New Conversation":
            words = content.strip().split()
            session.title = " ".join(words[:6]) if words else "Conversation"

        # Entity discovery and extraction
        discovered_entities = ReferenceResolver.extract_entities_from_text(content, role, turn_idx)
        for ent in discovered_entities:
            existing = session.entities.get(ent.name)
            if existing:
                existing.last_mentioned_turn = turn_idx
                if ent.gender and not existing.gender:
                    existing.gender = ent.gender
                existing.relations.update(ent.relations)
            else:
                session.entities[ent.name] = ent

        # Update active focus entity
        if discovered_entities:
            # Person entities take precedence for active focus
            person_entities = [e for e in discovered_entities if e.entity_type == "person"]
            new_focus = person_entities[-1].name if person_entities else discovered_entities[-1].name
            if session.active_focus_entity and session.active_focus_entity != new_focus:
                session.previous_focus_entity = session.active_focus_entity
            session.active_focus_entity = new_focus

        self.save_session(session)
        return msg

    # ── Context Summarization & Token Budgeting ───────────────────────────────

    def _summarize_older_messages(self, messages_to_compress: List[Message], current_summary: str) -> str:
        """
        Compresses turns exceeding the recent sliding window into a factual,
        entity-preserving narrative summary.
        """
        lines = []
        if current_summary:
            lines.append(f"Prior summary: {current_summary}")

        for m in messages_to_compress:
            role_label = "User" if m.role == "user" else "Galaxy Vision"
            # Extract key 1-2 sentence essence
            first_sentence = m.content.strip().split("\n")[0][:180]
            lines.append(f"- {role_label}: {first_sentence}")

        compressed = " | ".join(lines)
        # Keep under 600 chars
        if len(compressed) > 600:
            compressed = compressed[:600] + "..."
        return compressed

    # ── Model Payload Preparation ─────────────────────────────────────────────

    def build_model_messages(
        self,
        session_id: str,
        current_user_message: str,
        system_instruction: Optional[str] = None,
        images_b64: Optional[List[str]] = None,
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Constructs the complete, context-aware message sequence for the model:
        1. System prompt with identity and dialogue memory guidelines
        2. Context grounder (active focus entity, resolved pronouns/relations)
        3. Factual summary of older turns (if any)
        4. Sliding window of recent dialogue turns (verbatim)
        5. Current user prompt with reference grounding annotation
        """
        session = self.get_or_create_session(session_id)

        # 1. Resolve pronouns and references in the user message
        analysis = ReferenceResolver.analyze_query(current_user_message, session)

        # 2. Partition message history: older turns -> summary, recent turns -> raw
        all_prior = [m for m in session.messages if m.role in ("user", "assistant")]
        recent_cutoff = max(0, len(all_prior) - self.max_recent_turns)
        older_turns = all_prior[:recent_cutoff]
        recent_turns = all_prior[recent_cutoff:]

        if older_turns:
            session.summary = self._summarize_older_messages(older_turns, session.summary)

        # 3. Construct System Prompt + Dialogue Grounding
        base_system = system_instruction or (
            "You are Galaxy Vision (version 1.0.0), a multimodal vision-language AI developed and "
            "distributed by HS AI Solutions. Maintain natural conversational continuity, resolve pronouns "
            "using the dialogue history, and provide rigorous, accurate, and direct responses."
        )

        # Grounding cues block
        grounding_elements = []
        if session.active_focus_entity:
            focus_e = session.entities.get(session.active_focus_entity)
            desc = f"Active Subject/Focus: {session.active_focus_entity}"
            if focus_e and focus_e.relations:
                rels = ", ".join(f"{k}: {v}" for k, v in focus_e.relations.items())
                desc += f" (Relations: {rels})"
            grounding_elements.append(desc)

        if session.previous_focus_entity and session.previous_focus_entity != session.active_focus_entity:
            grounding_elements.append(f"Previous Subject: {session.previous_focus_entity}")

        if analysis.get("resolved_context_note"):
            grounding_elements.append(f"Reference Resolution: {analysis['resolved_context_note']}")

        if session.summary:
            grounding_elements.append(f"Prior Conversation Summary: {session.summary}")

        # Inject long-term profile facts if any
        lt_facts = self.long_term_memory.get("persistent_facts", [])
        if lt_facts:
            grounding_elements.append("User Notes: " + "; ".join(lt_facts[-3:]))

        if grounding_elements:
            system_content = f"{base_system}\n\n[CONVERSATIONAL CONTEXT & ENTITY MEMORY]\n" + "\n".join(f"• {g}" for g in grounding_elements)
        else:
            system_content = base_system

        # 4. Assemble the message sequence
        model_messages: List[Dict[str, Any]] = [
            {"role": "system", "content": system_content}
        ]

        # Add recent turns
        for m in recent_turns:
            model_messages.append({"role": m.role, "content": m.content})

        # Add current user turn
        user_turn_content: Any = current_user_message
        if images_b64:
            # If backend supports multimodal message format
            user_turn_dict = {"role": "user", "content": current_user_message, "images": images_b64}
            model_messages.append(user_turn_dict)
        else:
            model_messages.append({"role": "user", "content": user_turn_content})

        return model_messages, analysis

    def build_single_text_prompt(
        self,
        session_id: str,
        current_user_message: str,
        system_instruction: Optional[str] = None,
    ) -> Tuple[str, Dict[str, Any]]:
        """
        Formats the multi-turn context into a unified prompt string for models
        or APIs that accept a single prompt string.
        """
        messages, analysis = self.build_model_messages(
            session_id=session_id,
            current_user_message=current_user_message,
            system_instruction=system_instruction,
        )

        formatted_parts = []
        for m in messages:
            role = m["role"].upper()
            content = m["content"]
            if role == "SYSTEM":
                formatted_parts.append(f"### SYSTEM INSTRUCTIONS\n{content}\n")
            elif role == "USER":
                formatted_parts.append(f"User: {content}")
            elif role == "ASSISTANT":
                formatted_parts.append(f"Galaxy Vision: {content}")

        formatted_parts.append("Galaxy Vision:")
        return "\n\n".join(formatted_parts), analysis


# Singleton instance
_GLOBAL_CONTEXT_MANAGER: Optional[ContextManager] = None

def get_context_manager() -> ContextManager:
    global _GLOBAL_CONTEXT_MANAGER
    if _GLOBAL_CONTEXT_MANAGER is None:
        _GLOBAL_CONTEXT_MANAGER = ContextManager()
    return _GLOBAL_CONTEXT_MANAGER
