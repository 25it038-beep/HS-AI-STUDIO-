"""Vision processing utilities and high-level multimodal routines for Galaxy Vision."""

from __future__ import annotations

import base64
import io
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from PIL import Image

if TYPE_CHECKING:
    from .inference import GalaxyVision, GenerationResponse

logger = logging.getLogger("galaxy_vision.vision")

SUPPORTED_IMAGE_FORMATS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


@dataclass
class VisionAnalysisResult:
    """Structured result returned by vision operations."""
    text: str
    model: str
    task: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    latency_sec: float = 0.0


def encode_image_to_base64(image_input: Union[str, Path, bytes, Image.Image]) -> str:
    """Convert file path, raw bytes, or PIL Image into a base64 encoded string."""
    if isinstance(image_input, (str, Path)):
        p = Path(image_input)
        if not p.is_file():
            raise FileNotFoundError(f"Image file not found: {p}")
        suffix = p.suffix.lower()
        if suffix not in SUPPORTED_IMAGE_FORMATS:
            logger.warning("Uncommon image extension '%s'; attempting to read anyway.", suffix)
        with open(p, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")

    elif isinstance(image_input, bytes):
        return base64.b64encode(image_input).decode("utf-8")

    elif isinstance(image_input, Image.Image):
        buf = io.BytesIO()
        fmt = image_input.format or "PNG"
        image_input.save(buf, format=fmt)
        return base64.b64encode(buf.getvalue()).decode("utf-8")

    raise TypeError(f"Unsupported image input type: {type(image_input)}")


def validate_and_preprocess_image(
    image_input: Union[str, Path, bytes],
    max_dimension: int = 2048,
    max_mb: float = 25.0
) -> bytes:
    """Validate image integrity, enforce file size limits, and normalize dimensions to safeguard VRAM."""
    raw_bytes: bytes
    if isinstance(image_input, (str, Path)):
        p = Path(image_input)
        if not p.is_file():
            raise FileNotFoundError(f"Image file not found: {p}")
        size_mb = p.stat().st_size / (1024 * 1024)
        if size_mb > max_mb:
            raise ValueError(f"Image file size ({size_mb:.2f} MB) exceeds maximum allowed limit of {max_mb} MB.")
        with open(p, "rb") as f:
            raw_bytes = f.read()
    elif isinstance(image_input, bytes):
        size_mb = len(image_input) / (1024 * 1024)
        if size_mb > max_mb:
            raise ValueError(f"Image payload ({size_mb:.2f} MB) exceeds maximum allowed limit of {max_mb} MB.")
        raw_bytes = image_input
    else:
        raise TypeError("Expected filepath or raw bytes for image validation.")

    # Validate image format and dimensions via Pillow
    try:
        with Image.open(io.BytesIO(raw_bytes)) as img:
            img.verify()
    except Exception as err:
        raise ValueError(f"Invalid or corrupted image format: {err}") from err

    # Re-open for potential resizing to safeguard 6GB VRAM
    with Image.open(io.BytesIO(raw_bytes)) as img:
        img_format = img.format or "PNG"
        width, height = img.size
        if width > max_dimension or height > max_dimension:
            scale = max_dimension / max(width, height)
            new_size = (int(width * scale), int(height * scale))
            logger.info("Resizing oversized image from %sx%s to %sx%s", width, height, new_size[0], new_size[1])
            resized = img.resize(new_size, Image.Resampling.LANCZOS)
            out_buf = io.BytesIO()
            resized.save(out_buf, format=img_format)
            return out_buf.getvalue()

    return raw_bytes


class VisionEngine:
    """Specialized high-level multimodal routines executing against GalaxyVision."""

    def __init__(self, engine: "GalaxyVision"):
        self.engine = engine

    def describe(self, image: Union[str, Path, bytes], detail: str = "detailed") -> VisionAnalysisResult:
        """Generate a factual, grounded description of the image."""
        prompts = {
            "brief": "Provide a concise, 1-2 sentence description of the key visual elements in this image.",
            "detailed": (
                "Provide a comprehensive, factual description of this image. Describe foreground subjects, "
                "background environment, spatial arrangement, colors, textures, and any visible text or symbols. "
                "Do not speculate on unseen details."
            ),
            "objects": "Identify and catalog all prominent objects, entities, and subjects visible in this image."
        }
        prompt = prompts.get(detail, prompts["detailed"])
        resp = self.engine.analyze_image(image_path=image, prompt=prompt)
        return VisionAnalysisResult(
            text=resp.text,
            model=resp.model,
            task=f"describe_{detail}",
            latency_sec=resp.total_duration_sec,
            metadata={"detail": detail}
        )

    def extract_text(self, image: Union[str, Path, bytes]) -> VisionAnalysisResult:
        """Extract and transcribe all visible textual content (OCR)."""
        prompt = (
            "Extract and transcribe all legible text from this image exactly as written. "
            "Maintain original formatting, capitalization, line breaks, and numbers. "
            "If no text is visible, clearly state that no text was detected."
        )
        resp = self.engine.analyze_image(image_path=image, prompt=prompt)
        return VisionAnalysisResult(
            text=resp.text,
            model=resp.model,
            task="ocr",
            latency_sec=resp.total_duration_sec
        )

    def ask(self, image: Union[str, Path, bytes], question: str) -> VisionAnalysisResult:
        """Answer a specific visual question about the image."""
        prompt = (
            f"Based strictly on the visual evidence in this image, answer the following question: {question}\n"
            "If the answer cannot be determined directly from the image, state that the information is unavailable."
        )
        resp = self.engine.analyze_image(image_path=image, prompt=prompt)
        return VisionAnalysisResult(
            text=resp.text,
            model=resp.model,
            task="vqa",
            latency_sec=resp.total_duration_sec,
            metadata={"question": question}
        )

    def compare(
        self,
        images: List[Union[str, Path, bytes]],
        prompt: str = "Compare these images, noting differences, similarities, and visual changes."
    ) -> VisionAnalysisResult:
        """Compare multiple images."""
        if not images:
            raise ValueError("At least one image must be provided for comparison.")
        base64_list = [encode_image_to_base64(img) for img in images]
        
        # Execute chat completion with multiple images
        resp = self.engine.backend.generate(
            model=self.engine.model_name,
            prompt=prompt,
            images=base64_list,
            timeout=self.engine.config.request_timeout
        )
        return VisionAnalysisResult(
            text=resp.text,
            model=resp.model,
            task="compare",
            latency_sec=resp.total_duration_sec,
            metadata={"image_count": len(images)}
        )
