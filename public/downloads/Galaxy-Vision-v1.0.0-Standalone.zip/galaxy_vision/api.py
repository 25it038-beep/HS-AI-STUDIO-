"""FastAPI backend for HS AI Solutions Galaxy Vision.

Serves the Galaxy Vision HTML UI and provides the REST API.

Key endpoints:
  GET  /                        — Galaxy Vision HTML studio
  GET  /health                  — Health JSON
  GET  /v1/models               — OpenAI-compatible model list
  POST /api/vision/chat         — Main UI endpoint (multimodal chat)
  POST /v1/chat/completions     — OpenAI-compatible chat
  POST /v1/vision/analyze       — Image analysis (multipart)
  POST /v1/video/analyze        — Video frame analysis (multipart)
  POST /v1/documents/analyze    — Document OCR & extraction (multipart)
  POST /v1/batch/analyze        — Multi-file batch (multipart)
  POST /v1/screenshot/analyze   — Live screen capture + analysis
  POST /v1/search/web           — Web search + AI synthesis
"""

from __future__ import annotations

import base64
import logging
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Request, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .config import GalaxyVisionConfig, get_config
from .context import get_context_manager
from .health import get_system_health
from .inference import GalaxyVision
from .screenshot import ScreenshotEngine, capture_screen
from .websearch import WebSearchEngine

logger = logging.getLogger("galaxy_vision.api")

cfg = get_config()

app = FastAPI(
    title="HS AI Solutions Galaxy Vision API",
    version=cfg.version,
    description="Galaxy Vision 1.0.0 — Multimodal Vision-Language AI by HS AI Solutions",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Static files (UI) ─────────────────────────────────────────────────────────
_UI_DIR = Path(__file__).parent.parent / "ui"
if _UI_DIR.is_dir():
    app.mount("/ui", StaticFiles(directory=str(_UI_DIR)), name="ui")

# ── Engine singleton ──────────────────────────────────────────────────────────
_ENGINE: Optional[GalaxyVision] = None


def get_engine() -> GalaxyVision:
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = GalaxyVision(config=get_config())
    return _ENGINE


# ── Auth (optional) ───────────────────────────────────────────────────────────

def verify_api_key(
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
    authorization: Optional[str] = Header(None),
):
    expected = get_config().api_key
    if not expected:
        return
    if x_api_key and x_api_key == expected:
        return
    if authorization:
        parts = authorization.split()
        if len(parts) == 2 and parts[0].lower() == "bearer" and parts[1] == expected:
            return
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key.")


# ── Pydantic schemas ──────────────────────────────────────────────────────────

class ChatMessage(BaseModel):
    role: str
    content: Union[str, List[Dict[str, Any]]]
    images: Optional[List[str]] = None


class ChatCompletionRequest(BaseModel):
    model: Optional[str] = None
    messages: List[ChatMessage]
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    max_tokens: Optional[int] = None
    stream: bool = False


class VisionAnalyzeJsonRequest(BaseModel):
    image_base64: str
    prompt: str = "Analyze this image and describe its key elements in detail."
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class GalaxyVisionChatFile(BaseModel):
    """A file sent inline from the Galaxy Vision HTML UI."""
    name: str
    mimeType: str
    data: str  # base64-encoded


class GalaxyVisionChatRequest(BaseModel):
    """Request body for POST /api/vision/chat (from the HTML UI)."""
    model: str = "galaxy-vision"
    message: str = ""
    conversation_id: Optional[str] = None
    messages: Optional[List[Dict[str, Any]]] = None
    images: List[GalaxyVisionChatFile] = []
    files: List[GalaxyVisionChatFile] = []
    webSearch: bool = False


class WebSearchRequest(BaseModel):
    query: str
    max_results: int = 6


# ── Helpers ───────────────────────────────────────────────────────────────────

def _validate_upload_size(data: bytes, label: str = "File"):
    max_bytes = cfg.max_upload_mb * 1_048_576
    if len(data) > max_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"{label} exceeds maximum size of {cfg.max_upload_mb} MB.",
        )


# ══════════════════════════════════════════════════════════════════════════════
# ROOT — Serve Galaxy Vision HTML UI
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def serve_ui():
    """Serve the Galaxy Vision HTML studio interface."""
    index_path = _UI_DIR / "index.html"
    if index_path.is_file():
        return HTMLResponse(content=index_path.read_text(encoding="utf-8"))
    # Fallback minimal page if UI dir not found
    return HTMLResponse(content="""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Galaxy Vision</title>
<style>body{background:#08090c;color:#c5f77a;font-family:sans-serif;
display:flex;justify-content:center;align-items:center;min-height:100vh;
text-align:center;}h1{font-size:2rem;}p{color:#8a8f9e;}</style></head>
<body><div><h1>🌌 Galaxy Vision</h1>
<p>UI not found. Place <code>ui/index.html</code> in the galaxy-vision directory.</p>
<p>API is running — visit <a href="/docs" style="color:#9baaff">/docs</a></p>
</div></body></html>""")


# ══════════════════════════════════════════════════════════════════════════════
# HEALTH
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/health")
@app.get("/v1/health")
async def health():
    engine = get_engine()
    return engine.health()


# ══════════════════════════════════════════════════════════════════════════════
# MODELS
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/v1/models")
async def list_models(_: None = Depends(verify_api_key)):
    ts = int(time.time())
    return {
        "object": "list",
        "data": [
            {
                "id": "galaxy-vision",
                "object": "model",
                "created": ts,
                "owned_by": "hs-ai-solutions",
                "capabilities": ["vision", "text", "ocr", "document", "video"],
            },
            {
                "id": "galaxy-vision:1.0",
                "object": "model",
                "created": ts,
                "owned_by": "hs-ai-solutions",
                "capabilities": ["vision", "text", "ocr", "document", "video"],
            },
        ],
    }


# ══════════════════════════════════════════════════════════════════════════════
# /api/vision/chat — PRIMARY ENDPOINT for Galaxy Vision HTML UI
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/api/vision/chat")
async def galaxy_vision_chat(
    req: GalaxyVisionChatRequest,
    _: None = Depends(verify_api_key),
):
    """
    Main multimodal chat endpoint consumed by the Galaxy Vision HTML UI.

    Supports multi-turn conversational context, pronoun resolution,
    and entity tracking across sessions.
    """
    engine = get_engine()
    t0 = time.perf_counter()
    ctx_mgr = get_context_manager()
    conv_id = req.conversation_id or "default-session"

    try:
        # ── Web Search mode ──────────────────────────────────────────────────
        if req.webSearch and req.message:
            ws = WebSearchEngine(engine)
            result = ws.search_and_answer(query=req.message)
            ctx_mgr.register_turn(conv_id, "user", req.message)
            ctx_mgr.register_turn(conv_id, "assistant", result.answer)
            return {
                "reply": result.answer,
                "sources": result.sources,
                "latency_sec": result.latency_sec,
                "model": "galaxy-vision",
                "conversation_id": conv_id,
            }

        # ── Vision mode — images attached ────────────────────────────────────
        if req.images:
            parts = []
            for img_file in req.images:
                img_bytes = base64.b64decode(img_file.data)
                _validate_upload_size(img_bytes, img_file.name)
                resp = engine.analyze_image(
                    image_path=img_bytes,
                    prompt=req.message or "Analyze this image in detail.",
                )
                parts.append(f"**{img_file.name}:**\n{resp.text}")

            combined = "\n\n---\n\n".join(parts)
            user_text = req.message or "Analyze this image in detail."
            ctx_mgr.register_turn(conv_id, "user", user_text, metadata={"images": [f.name for f in req.images]})
            ctx_mgr.register_turn(conv_id, "assistant", combined)
            return {
                "reply": combined,
                "model": "galaxy-vision",
                "latency_sec": round(time.perf_counter() - t0, 2),
                "conversation_id": conv_id,
            }

        # ── Document mode — non-image files attached ─────────────────────────
        if req.files:
            parts = []
            for doc_file in req.files:
                doc_bytes = base64.b64decode(doc_file.data)
                _validate_upload_size(doc_bytes, doc_file.name)

                if doc_file.mimeType.startswith("image/"):
                    resp = engine.analyze_image(
                        image_path=doc_bytes,
                        prompt=req.message or "Analyze and transcribe this document.",
                    )
                    parts.append(f"**{doc_file.name}:**\n{resp.text}")
                else:
                    try:
                        text_content = doc_bytes.decode("utf-8", errors="replace")[:8000]
                    except Exception:
                        text_content = f"[Binary file: {doc_file.name}]"
                    combined_prompt = (
                        f"The user has uploaded a file named '{doc_file.name}'.\n"
                        f"File content (first 8000 characters):\n\n{text_content}\n\n"
                        f"User instruction: {req.message or 'Summarize and extract key information.'}"
                    )
                    resp = engine.generate(prompt=combined_prompt)
                    parts.append(f"**{doc_file.name}:**\n{resp.text}")

            combined = "\n\n---\n\n".join(parts)
            user_text = req.message or "Analyze document"
            ctx_mgr.register_turn(conv_id, "user", user_text, metadata={"files": [f.name for f in req.files]})
            ctx_mgr.register_turn(conv_id, "assistant", combined)
            return {
                "reply": combined,
                "model": "galaxy-vision",
                "latency_sec": round(time.perf_counter() - t0, 2),
                "conversation_id": conv_id,
            }

        # ── Text mode with Multi-turn Context & Reference Resolution ────────
        if not req.message:
            raise HTTPException(status_code=400, detail="Provide a message, image, or file.")

        resp, analysis = engine.chat_turn(
            conversation_id=conv_id,
            message=req.message,
            stream=False,
        )

        session = ctx_mgr.get_or_create_session(conv_id)

        return {
            "reply": resp.text,
            "model": "galaxy-vision",
            "latency_sec": round(time.perf_counter() - t0, 2),
            "tokens": resp.completion_tokens,
            "conversation_id": conv_id,
            "active_focus": session.active_focus_entity,
            "resolved_subject": analysis.get("resolved_subject"),
            "resolution_note": analysis.get("resolved_context_note"),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error("galaxy_vision_chat error: %s", e)
        raise HTTPException(status_code=500, detail=f"Inference failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# CONVERSATION MANAGEMENT & MEMORY ENDPOINTS
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/conversations")
async def list_conversations(_: None = Depends(verify_api_key)):
    """List all persisted conversation sessions."""
    ctx_mgr = get_context_manager()
    return {"conversations": ctx_mgr.list_sessions()}


@app.post("/api/conversations")
async def create_conversation(_: None = Depends(verify_api_key)):
    """Create a new isolated conversation session."""
    ctx_mgr = get_context_manager()
    session = ctx_mgr.get_or_create_session()
    return {"conversation_id": session.id, "title": session.title}


@app.get("/api/conversations/{conversation_id}")
async def get_conversation(conversation_id: str, _: None = Depends(verify_api_key)):
    """Retrieve full history, entities, and summary for a conversation."""
    ctx_mgr = get_context_manager()
    session = ctx_mgr.get_or_create_session(conversation_id)
    return session.to_dict()


@app.delete("/api/conversations/{conversation_id}")
async def delete_conversation(conversation_id: str, _: None = Depends(verify_api_key)):
    """Delete a conversation session."""
    ctx_mgr = get_context_manager()
    success = ctx_mgr.delete_session(conversation_id)
    return {"success": success, "deleted_id": conversation_id}


@app.delete("/api/conversations")
async def clear_all_conversations(_: None = Depends(verify_api_key)):
    """Clear all conversation sessions."""
    ctx_mgr = get_context_manager()
    deleted_count = ctx_mgr.clear_all_sessions()
    return {"success": True, "deleted_count": deleted_count}


@app.get("/api/memory")
async def get_long_term_memory(_: None = Depends(verify_api_key)):
    """Retrieve persistent long-term memory (Level C)."""
    ctx_mgr = get_context_manager()
    return ctx_mgr.long_term_memory


@app.post("/api/memory/fact")
async def add_long_term_fact(fact: str, _: None = Depends(verify_api_key)):
    """Add a permanent user fact to long-term memory."""
    ctx_mgr = get_context_manager()
    ctx_mgr.update_long_term_fact(fact)
    return {"success": True, "facts": ctx_mgr.long_term_memory.get("persistent_facts", [])}


@app.delete("/api/memory")
async def clear_long_term_memory(_: None = Depends(verify_api_key)):
    """Clear long-term memory."""
    ctx_mgr = get_context_manager()
    ctx_mgr.clear_long_term_memory()
    return {"success": True}


# ══════════════════════════════════════════════════════════════════════════════
# OpenAI-compatible /v1/chat/completions
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/chat/completions")
async def chat_completions(
    req: ChatCompletionRequest,
    _: None = Depends(verify_api_key),
):
    engine = get_engine()
    t0 = time.perf_counter()

    messages = [m.model_dump() for m in req.messages]
    resp = engine.chat(
        messages=messages,
        temperature=req.temperature,
        top_p=req.top_p,
        max_tokens=req.max_tokens,
    )
    wall = time.perf_counter() - t0
    ts = int(time.time())

    return {
        "id": f"chatcmpl-galaxy-{ts}",
        "object": "chat.completion",
        "created": ts,
        "model": req.model or "galaxy-vision",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": resp.text},
                "finish_reason": resp.finish_reason,
            }
        ],
        "usage": {
            "prompt_tokens": resp.prompt_tokens,
            "completion_tokens": resp.completion_tokens,
            "total_tokens": resp.prompt_tokens + resp.completion_tokens,
        },
    }


# ══════════════════════════════════════════════════════════════════════════════
# /v1/vision/analyze — Image upload (multipart)
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/vision/analyze")
async def vision_analyze(
    file: UploadFile = File(...),
    prompt: str = Form("Describe this image in detail."),
    temperature: Optional[float] = Form(None),
    max_tokens: Optional[int] = Form(None),
    _: None = Depends(verify_api_key),
):
    engine = get_engine()
    data = await file.read()
    _validate_upload_size(data, file.filename or "image")
    t0 = time.perf_counter()
    resp = engine.analyze_image(
        image_path=data,
        prompt=prompt,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return {
        "text": resp.text,
        "model": resp.model,
        "latency_sec": round(time.perf_counter() - t0, 2),
        "completion_tokens": resp.completion_tokens,
    }


# ══════════════════════════════════════════════════════════════════════════════
# /v1/vision/analyze:json — Image as base64 JSON body
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/vision/analyze:json")
async def vision_analyze_json(
    req: VisionAnalyzeJsonRequest,
    _: None = Depends(verify_api_key),
):
    engine = get_engine()
    img_bytes = base64.b64decode(req.image_base64)
    _validate_upload_size(img_bytes, "image")
    t0 = time.perf_counter()
    resp = engine.analyze_image(
        image_path=img_bytes,
        prompt=req.prompt,
        temperature=req.temperature,
        max_tokens=req.max_tokens,
    )
    return {
        "text": resp.text,
        "model": resp.model,
        "latency_sec": round(time.perf_counter() - t0, 2),
    }


# ══════════════════════════════════════════════════════════════════════════════
# /v1/video/analyze — Video multipart upload
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/video/analyze")
async def video_analyze(
    file: UploadFile = File(...),
    prompt: str = Form("Summarize key events in chronological order."),
    sample_interval_sec: float = Form(1.0),
    max_frames: int = Form(8),
    _: None = Depends(verify_api_key),
):
    engine = get_engine()
    data = await file.read()
    _validate_upload_size(data, file.filename or "video")
    suffix = Path(file.filename or "video.mp4").suffix or ".mp4"
    t0 = time.perf_counter()
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(data)
        tmp_path = tmp.name
    try:
        result = engine.analyze_video(
            video_path=tmp_path,
            prompt=prompt,
            sample_interval_sec=sample_interval_sec,
            max_frames=max_frames,
        )
        return {
            "text": result.text,
            "model": "galaxy-vision",
            "sampled_frames": result.sampled_frames_count,
            "duration_sec": result.duration_sec,
            "fps": result.fps,
            "timestamps": result.frame_timestamps,
            "limitations": result.limitations,
            "latency_sec": round(time.perf_counter() - t0, 2),
        }
    finally:
        Path(tmp_path).unlink(missing_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# /v1/documents/analyze — Document OCR (multipart)
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/documents/analyze")
async def document_analyze(
    file: UploadFile = File(...),
    prompt: str = Form("Transcribe all text and extract structured information."),
    extract_tables: bool = Form(True),
    return_json: bool = Form(True),
    _: None = Depends(verify_api_key),
):
    engine = get_engine()
    data = await file.read()
    _validate_upload_size(data, file.filename or "document")
    t0 = time.perf_counter()
    result = engine.analyze_document(
        document_path=data,
        prompt=prompt,
        extract_tables=extract_tables,
        return_json=return_json,
    )
    return {
        "text": result.text,
        "tables": result.tables,
        "structured_data": result.structured_data,
        "latency_sec": result.latency_sec or round(time.perf_counter() - t0, 2),
    }


# ══════════════════════════════════════════════════════════════════════════════
# /v1/batch/analyze — Multi-file batch
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/batch/analyze")
async def batch_analyze(
    files: List[UploadFile] = File(...),
    prompt: str = Form("Analyze this file thoroughly and extract key information."),
    _: None = Depends(verify_api_key),
):
    engine = get_engine()
    results = []
    video_exts = {".mp4", ".avi", ".mov", ".mkv", ".webm"}
    t_batch = time.perf_counter()

    for upload in files:
        data = await upload.read()
        fname = upload.filename or "file"
        ext = Path(fname).suffix.lower()
        t0 = time.perf_counter()
        try:
            _validate_upload_size(data, fname)
            if ext in video_exts:
                with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
                    tmp.write(data)
                    tmp_path = tmp.name
                try:
                    vr = engine.analyze_video(video_path=tmp_path, prompt=prompt)
                    results.append({
                        "filename": fname, "type": "video",
                        "status": "verified_processed",
                        "summary": vr.text,
                        "latency_sec": round(time.perf_counter() - t0, 2),
                    })
                finally:
                    Path(tmp_path).unlink(missing_ok=True)
            else:
                ir = engine.analyze_image(image_path=data, prompt=prompt)
                results.append({
                    "filename": fname, "type": "image",
                    "status": "verified_processed",
                    "summary": ir.text,
                    "tokens": ir.completion_tokens,
                    "latency_sec": round(time.perf_counter() - t0, 2),
                })
        except Exception as e:
            results.append({
                "filename": fname, "status": "failed",
                "error": str(e), "latency_sec": round(time.perf_counter() - t0, 2),
            })

    ok = sum(1 for r in results if r.get("status") == "verified_processed")
    return {
        "total_files": len(results),
        "processed_successfully": ok,
        "all_files_verified": ok == len(results),
        "failed": len(results) - ok,
        "total_latency_sec": round(time.perf_counter() - t_batch, 2),
        "results": results,
    }


# ══════════════════════════════════════════════════════════════════════════════
# /v1/screenshot/capture — Return screen PNG as base64
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/screenshot/capture")
async def screenshot_capture(
    monitor_index: int = Form(1),
    _: None = Depends(verify_api_key),
):
    try:
        png = capture_screen(monitor_index=monitor_index)
        return {
            "image_base64": base64.b64encode(png).decode(),
            "format": "png",
            "size_bytes": len(png),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Screenshot capture failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# /v1/screenshot/analyze — Capture + analyze screen
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/screenshot/analyze")
async def screenshot_analyze(
    prompt: str = Form("Analyze this screenshot in detail."),
    monitor_index: int = Form(1),
    _: None = Depends(verify_api_key),
):
    engine = get_engine()
    se = ScreenshotEngine(engine)
    try:
        t0 = time.perf_counter()
        result = se.capture_and_analyze(prompt=prompt, monitor_index=monitor_index)
        return {
            "text": result.text,
            "image_base64": base64.b64encode(result.screenshot_bytes).decode(),
            "width": result.width,
            "height": result.height,
            "latency_sec": result.latency_sec or round(time.perf_counter() - t0, 2),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Screenshot analysis failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# /v1/search/web — DuckDuckGo search + AI synthesis
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/v1/search/web")
async def web_search(
    req: WebSearchRequest,
    _: None = Depends(verify_api_key),
):
    engine = get_engine()
    ws = WebSearchEngine(engine)
    try:
        result = ws.search_and_answer(query=req.query, max_results=req.max_results)
        return {
            "query": result.query,
            "answer": result.answer,
            "sources": result.sources,
            "num_results_used": result.num_results_used,
            "latency_sec": result.latency_sec,
            "model": result.model,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Web search failed: {e}")
