"""HS AI Solutions Galaxy Vision: Multimodal Vision-Language AI System.

Version: 1.0.0
Developer: HS AI Solutions
Family: Galaxy
"""

from .config import GalaxyVisionConfig, get_config
from .document_processing import DocumentAnalysisResult, DocumentProcessor
from .health import check_gpu, check_system_ram, get_system_health
from .inference import GalaxyVision, GalaxyVisionInferenceError, GenerationResponse
from .model_loader import ModelInfo, ModelLoader
from .screenshot import ScreenshotEngine, ScreenshotResult, capture_screen
from .video import VideoAnalysisResult, VideoProcessor
from .vision import VisionAnalysisResult, VisionEngine
from .websearch import WebSearchEngine, WebSearchResponse, search_web

__version__ = "1.0.0"
__author__ = "HS AI Solutions"

__all__ = [
    "GalaxyVision",
    "GalaxyVisionConfig",
    "get_config",
    "GenerationResponse",
    "GalaxyVisionInferenceError",
    "VisionEngine",
    "VisionAnalysisResult",
    "VideoProcessor",
    "VideoAnalysisResult",
    "DocumentProcessor",
    "DocumentAnalysisResult",
    "ModelLoader",
    "ModelInfo",
    "ScreenshotEngine",
    "ScreenshotResult",
    "capture_screen",
    "WebSearchEngine",
    "WebSearchResponse",
    "search_web",
    "get_system_health",
    "check_gpu",
    "check_system_ram",
    "__version__",
]
