"""Document understanding and layout analysis subsystem for Galaxy Vision.

Specializes in OCR, tabular extraction, receipts, invoices, forms,
and structured JSON parsing from document images.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from .vision import encode_image_to_base64

if TYPE_CHECKING:
    from .config import GalaxyVisionConfig
    from .inference import GalaxyVision

logger = logging.getLogger("galaxy_vision.document_processing")


@dataclass
class DocumentAnalysisResult:
    """Structured result from document and OCR processing."""
    text: str
    model: str
    document_type: str = "document"
    structured_data: Optional[Dict[str, Any]] = None
    tables: List[Dict[str, Any]] = field(default_factory=list)
    raw_markdown: str = ""
    latency_sec: float = 0.0


class DocumentProcessor:
    """High-level document processing, OCR, and table extraction engine."""

    def __init__(self, engine: "GalaxyVision", config: Optional["GalaxyVisionConfig"] = None):
        self.engine = engine
        self.config = config or engine.config

    def process_document(
        self,
        document_path: Union[str, Path, bytes],
        prompt: Optional[str] = None,
        extract_tables: bool = True,
        return_json: bool = False,
        **kwargs
    ) -> DocumentAnalysisResult:
        """Process scanned document, form, or screenshot."""
        base_prompt = prompt or (
            "Analyze this document image in full detail.\n"
            "1. Transcribe all text with exact fidelity.\n"
            "2. Identify headings, paragraphs, and lists.\n"
            "3. If any tables are present, render them in clean Markdown table format.\n"
            "4. Maintain numerical precision (dates, currencies, IDs)."
        )

        if return_json:
            base_prompt += (
                "\n\nIn addition to the transcription, output a valid JSON block at the bottom wrapped in "
                "```json ... ``` extracting all key-value fields (e.g. document_title, date, issuer, "
                "line_items, totals, summary)."
            )

        resp = self.engine.analyze_image(
            image_path=document_path,
            prompt=base_prompt,
            **kwargs
        )

        output_text = resp.text
        structured: Optional[Dict[str, Any]] = None
        if return_json:
            structured = self._extract_json_block(output_text)

        tables = self._extract_markdown_tables(output_text) if extract_tables else []

        return DocumentAnalysisResult(
            text=output_text,
            model=resp.model,
            document_type="document",
            structured_data=structured,
            tables=tables,
            raw_markdown=output_text,
            latency_sec=resp.total_duration_sec
        )

    def process_receipt_or_invoice(
        self,
        document_path: Union[str, Path, bytes],
        **kwargs
    ) -> DocumentAnalysisResult:
        """Specialized extractor for invoices, receipts, and financial slips."""
        prompt = (
            "You are a specialized document intelligence model. Extract all structured financial data "
            "from this receipt or invoice.\n\n"
            "Output your findings as a valid JSON object formatted inside ```json ... ``` with keys:\n"
            "- vendor_name: string\n"
            "- invoice_number: string or null\n"
            "- invoice_date: string\n"
            "- currency: string (e.g. USD, EUR, INR)\n"
            "- line_items: array of objects with description, quantity, unit_price, total_price\n"
            "- tax_amount: number or null\n"
            "- subtotal: number\n"
            "- total_amount: number\n"
            "- payment_method: string or null\n\n"
            "Follow strict JSON syntax and avoid inventing missing values."
        )

        resp = self.engine.analyze_image(image_path=document_path, prompt=prompt, **kwargs)
        structured = self._extract_json_block(resp.text)

        return DocumentAnalysisResult(
            text=resp.text,
            model=resp.model,
            document_type="invoice_receipt",
            structured_data=structured,
            raw_markdown=resp.text,
            latency_sec=resp.total_duration_sec
        )

    def _extract_json_block(self, text: str) -> Optional[Dict[str, Any]]:
        """Find and parse a JSON code block from model response."""
        json_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
        candidate = json_match.group(1) if json_match else text

        try:
            return json.loads(candidate.strip())
        except Exception:
            # Try to search for first { and last }
            start = candidate.find("{")
            end = candidate.rfind("}")
            if start != -1 and end != -1 and end > start:
                try:
                    return json.loads(candidate[start:end+1])
                except Exception:
                    pass
            logger.debug("Failed to parse structured JSON from document response.")
            return None

    def _extract_markdown_tables(self, text: str) -> List[Dict[str, Any]]:
        """Identify markdown tables in the response text and convert to structured rows."""
        tables: List[Dict[str, Any]] = []
        lines = text.splitlines()
        current_table: List[str] = []

        for line in lines:
            stripped = line.strip()
            if stripped.startswith("|") and stripped.endswith("|"):
                current_table.append(stripped)
            else:
                if len(current_table) >= 3:
                    table_obj = self._parse_single_markdown_table(current_table)
                    if table_obj:
                        tables.append(table_obj)
                current_table = []

        if len(current_table) >= 3:
            table_obj = self._parse_single_markdown_table(current_table)
            if table_obj:
                tables.append(table_obj)

        return tables

    def _parse_single_markdown_table(self, lines: List[str]) -> Optional[Dict[str, Any]]:
        """Parse rows and headers from markdown pipe-delimited table."""
        try:
            headers = [c.strip() for c in lines[0].split("|")[1:-1]]
            rows: List[List[str]] = []
            for r in lines[2:]:  # Skip delimiter line
                cols = [c.strip() for c in r.split("|")[1:-1]]
                if len(cols) == len(headers):
                    rows.append(cols)
            return {"headers": headers, "rows": rows, "row_count": len(rows)}
        except Exception:
            return None
