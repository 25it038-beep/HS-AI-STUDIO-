# Galaxy Vision System Architecture

**Product:** HS AI Solutions Galaxy Vision  
**Version:** 1.0.0  
**Author:** HS AI Solutions Multimodal Architecture Team  
**Status:** Approved for Production Distribution  

---

## 1. Architectural Overview

HS AI Solutions Galaxy Vision is a customized multimodal vision-language model distribution engineered for high-precision visual reasoning, OCR, document intelligence, and temporal video analysis in resource-constrained edge and workstation environments.

Galaxy Vision decouples client applications from low-level inference engines through a layered architecture:

```mermaid
flowchart TD
    subgraph Clients["Client Interface Layer"]
        CLI["Galaxy Vision CLI\n(galaxy-vision)"]
        API["FastAPI Local Server\n(/v1/chat, /v1/vision, /v1/video)"]
        SDK["Python SDK\n(GalaxyVision Client)"]
    end

    subgraph Orchestration["Multimodal Orchestration Layer"]
        VE["Vision Engine\n(Preprocess & Validation)"]
        VP["Video Processor\n(OpenCV Frame Extraction & Timestamps)"]
        DP["Document Processor\n(OCR, Tables, Structured JSON)"]
        HL["Health & VRAM Guard\n(psutil, nvidia-smi diagnostics)"]
    end

    subgraph BackendAbstraction["Backend Abstraction Layer"]
        BE["GalaxyVisionBackend (Abstract)"]
        OB["OllamaBackend (Local HTTP/GGUF)"]
        TB["Future Backends (Transformers / vLLM)"]
    end

    subgraph ModelFoundation["Foundation Weights Layer"]
        GV["galaxy-vision:1.0\n(HS AI System Grounding + Context Budget)"]
        UB["Upstream Base: qwen3-vl:4b-instruct\n(4.4B Parameters, Q4_K_M Quantization)"]
    end

    CLI --> SDK
    API --> SDK
    SDK --> VE
    SDK --> VP
    SDK --> DP
    SDK --> HL

    VE --> BE
    VP --> BE
    DP --> BE

    BE --> OB
    BE -.-> TB

    OB --> GV
    GV --> UB
```

---

## 2. Layer Specifications

### 2.1 Interface & Application Layer
* **Python SDK (`galaxy_vision.inference`):** High-level entrypoint `GalaxyVision` providing `.generate()`, `.chat()`, `.analyze_image()`, `.analyze_video()`, and `.analyze_document()`. Supports streaming and structured responses.
* **REST API (`galaxy_vision.api`):** FastAPI asynchronous service running on `http://127.0.0.1:8000`. Exposes OpenAI-compatible `/v1/chat/completions` and `/v1/models`, alongside dedicated `/v1/vision/analyze`, `/v1/video/analyze`, and `/v1/documents/analyze`.
* **Command Line Interface (`galaxy_vision.cli`):** Click and Rich-powered command-line tool providing interactive terminal chat, image inspection, video summaries, and live hardware health diagnostics.

### 2.2 Multimodal Processing Subsystems
* **Vision Engine (`galaxy_vision.vision`):** Image validation, aspect ratio preservation, automatic downsizing of oversized inputs exceeding 2048px to safeguard GPU VRAM, and base64 encoding.
* **Video Processor (`galaxy_vision.video`):** Asynchronous frame extraction via OpenCV (`cv2.VideoCapture`), sampling at user-defined intervals (default 1.0s) with microsecond timestamp tracking. Synthesizes discrete frames into chronological visual narratives with explicit operational disclaimers.
* **Document Processor (`galaxy_vision.document_processing`):** Specialized OCR extraction, markdown table parser, and robust regex-assisted JSON block extractor for receipts, invoices, and structured forms.

### 2.3 Model Customization Layer (Path A vs Path B)

#### Path A: Product Customization (Active in v1.0.0)
* **Custom Modelfile:** Inherits base weights `FROM qwen3-vl:4b-instruct`.
* **Branded Identity & Grounding:** Embeds the HS AI Solutions corporate identity, strict factual grounding, explicit instructions to avoid hallucinations on visual inputs, and acknowledgment of visual ambiguities.
* **Memory Optimization:** Clamps default context length to `8,192` tokens (`PARAMETER num_ctx 8192`), top_p to `0.90`, and temperature to `0.70`.
* **Zero Weight Degradation:** Preserves 100% of the upstream model's original 4.4B multimodal weights without alteration.

#### Path B: Behavioral Fine-Tuning / LoRA Adapters (Optional Future Extension)
* Evaluated for domain-specific fine-tuning (e.g. medical imaging, specialized CAD diagrams).
* Requires unsloth, trl, or PEFT with Qwen3-VL patch support.
* Kept strictly separated from default distribution to ensure maximum out-of-the-box reliability.

---

## 3. Hardware Resource Budgeting (Target: RTX 3050 6GB Laptop GPU)

Galaxy Vision is engineered to operate comfortably within a 6 GB VRAM envelope:

| Resource Component | Allocated Budget | Architectural Mitigation |
| :--- | :--- | :--- |
| **Model Weights (Q4_K_M)** | ~3.30 GB | 4-bit medium quantization ensures weights reside completely in VRAM. |
| **KV Cache (`num_ctx 8192`)** | ~1.15 GB | Base model defines 256k context; clamping to 8k prevents OOM and paging thrashing. |
| **Vision Embeddings** | ~0.75 GB | Input images scaled to max 2048px dimension; frames downsampled to 640x480. |
| **CUDA Buffers & Overhead** | ~0.60 GB | Managed by llama-server runtime. |
| **Safety Headroom** | ~0.34 GB | Safeguards against GPU desktop display allocations. |
| **Total VRAM Footprint** | **~5.80 GB / 6.14 GB** | **Stable GPU acceleration with zero swap.** |

---

## 4. Rollback and Non-Destructive Operation

Galaxy Vision maintains the upstream `qwen3-vl:4b-instruct` model completely intact:
1. Registration creates an independent tag: `galaxy-vision:1.0`.
2. Both tags share identical underlying layer blobs on disk (`sha256:16b83b...`), consuming zero extra disk storage.
3. Rollback command: `ollama rm galaxy-vision:1.0` instantaneously removes the customized tag without affecting the original model.
