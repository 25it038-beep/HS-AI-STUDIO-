# Upstream Model Audit: Qwen3-VL 4B Instruct

**Prepared for:** HS AI Solutions — Project Galaxy Vision  
**Audit Date:** October 21, 2026  
**Auditor:** Senior AI Infrastructure & Multimodal Model Architecture Team  
**Audit Status:** Verified & Validated  

---

## 1. Executive Summary

An audit of the locally installed multimodal foundation model was performed in the host environment to assess its suitability as the upstream base for the **Galaxy Vision 1.0.0** distribution.

The model registered under the local tag `qwen3-vl:4b-instruct` was inspected using Ollama diagnostic tools (`ollama list`, `ollama show`, and Modelfile inspection), programmatic API probes, and NVIDIA CUDA runtime diagnostics.

The base model is verified to exist locally, operates with full GPU acceleration on the host NVIDIA GeForce RTX 3050 Laptop GPU (6 GB VRAM), and demonstrates functional multimodal (vision + language) instruction-following and OCR performance under Apache License 2.0 terms.

---

## 2. Model Identification and Inventory

| Attribute | Inspected / Verified Value |
| :--- | :--- |
| **Model Name / Tag** | `qwen3-vl:4b-instruct` |
| **Local Model ID** | `ee4b975b58c1` |
| **Storage Footprint** | `3.3 GB` (compressed GGUF blob in Ollama cache) |
| **Upstream Developer** | Alibaba Cloud (Qwen Team) |
| **Architecture Family** | `qwen3vl` |
| **Total Parameters** | `4.4 Billion` (4.4B) |
| **Embedding Dimension** | `2560` |
| **Quantization Format** | `Q4_K_M` (4-bit medium k-quantization) |
| **Base Context Length** | `262,144` tokens (256K native maximum) |
| **Capabilities Reported**| `completion`, `vision`, `tools` |

---

## 3. Architecture & Modality Inspection

### 3.1 Vision Encoder & Image Processing
* **Vision Backbone:** Integrated vision transformer (ViT) matching the Qwen3-VL multimodal architecture with 2D patch-merging projection to the language model embedding dimension (2560).
* **Supported Image Formats:** JPEG, PNG, WebP, BMP (processed as RGB pixel arrays or base64-encoded bytes).
* **Input Resolution Handling:** Dynamic resolution adaptation. Image tokens are mapped to spatial patches; aspect ratios are preserved without non-uniform stretching.
* **Tested Visual Capabilities:** Confirmed functional in local tests for high-contrast OCR (`GALAXY VISION 101` test probe), object detection, and visual question answering (VQA).

### 3.2 Video Processing Support
* **Native Video Direct Stream Support:** **Not directly supported** via Ollama's REST or CLI interfaces for raw continuous video container files (.mp4, .avi, .mkv).
* **Implementation Finding:** Ollama accepts arrays of base64 images within message objects.
* **Architectural Strategy for Galaxy Vision:** A dedicated video extraction and temporal reasoning pipeline is required. Galaxy Vision will ingest video files, extract keyframes at configurable sample rates (or scene changes) with timestamp preservation, submit ordered frames through the multimodal inference pipeline, and construct chronologically synthesized visual narratives.

### 3.3 Text & Reasoning
* **Base Chat Template:** Renderer `qwen3-vl-instruct` and Parser `qwen3-vl-instruct`.
* **Hyperparameters in Base Model:** `temperature: 1.0`, `top_p: 0.95`, `top_k: 20`.
* **Tool Support:** Native tool calling tokens supported by chat parser.

---

## 4. Hardware Resource & Footprint Analysis

The target host hardware is a Windows laptop configured with:
* **System RAM:** 16.0 GB (Total visible: 15.97 GB; Free: ~4.8 GB prior to load).
* **GPU:** NVIDIA GeForce RTX 3050 Laptop GPU (6144 MiB / 6.0 GB VRAM).
* **Driver / CUDA:** Driver 592.82, CUDA 13.1.
* **Python Runtime:** Python 3.14.4 (with PyTorch 2.12.1, torchvision 0.27.1, OpenCV 5.0.0, Pillow 11.3.0, FastAPI 0.115.0).

### 4.1 Memory Profiling Under Inference
* **Initial Cold Load:** 10.38 seconds load duration into GPU memory.
* **Idle Loaded VRAM Usage:** 5,975 MiB / 6,144 MiB utilized by `llama-server.exe`.
* **Execution Throughput:** ~38.7 tokens/second evaluation throughput during baseline generation.
* **Context Length Consideration:** The base model defines a theoretical context of 262,144 tokens. Allocating a full 256K KV-cache inside 6 GB VRAM would cause GPU memory exhaustion and trigger CUDA out-of-memory errors or fallback to slow unified memory paging.
* **Galaxy Vision Configuration Decision:** For rock-solid stability on 6 GB VRAM hardware, Galaxy Vision sets a default context window of `8,192` tokens (`num_ctx 8192`), expandable up to 32,768 when memory permits, ensuring zero host memory thrashing.

---

## 5. Licensing and Legal Compliance

### 5.1 Upstream License
* **License Type:** **Apache License, Version 2.0 (January 2004)**.
* **Verification:** Confirmed directly from the embedded Modelfile blob.

### 5.2 Legal Rights Granted
* Section 2 grants a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, sublicense, and distribute the Work and such Derivative Works.
* Section 3 grants patent licenses under contributor claims.

### 5.3 Legal Obligations & Constraints
1. **Attribution:** Must retain copyright, patent, trademark, and attribution notices from the Source form of the Work (Section 4b).
2. **Prominent Notice of Changes:** Must cause any modified files to carry prominent notices stating that the files were altered (Section 4b).
3. **NOTICE File:** Must include a copy of the NOTICE text in any distribution (Section 4d).
4. **Trademark Restriction:** Section 6 explicitly states that the license does **not** grant permission to use the trade names, trademarks, service marks, or product names of the Licensor (Alibaba / Qwen), except as required for reasonable and customary use in describing the origin of the Work.

### 5.4 Galaxy Vision Compliance Strategy
* **Product Identity:** Branded distinctly as **HS AI Solutions Galaxy Vision**.
* **Attribution:** Upstream Qwen3-VL base model and Alibaba Cloud copyright explicitly acknowledged in `NOTICE`, `THIRD_PARTY_NOTICES.md`, and documentation.
* **Original Application IP:** Galaxy Vision Python interface, HTTP server, CLI, video frame sampling pipeline, document processing modules, and evaluation test suite are copyright HS AI Solutions.
* **No False Claims:** Clear disclaimer that HS AI Solutions engineered the customized distribution, system prompts, inference wrappers, and multi-modal pipeline, without falsely claiming to have independently trained the underlying 4.4B weights from scratch.

---

## 6. Customization & Distribution Roadmap

1. **Model Customization (Path A - Non-Destructive):**
   * Package custom Modelfile deriving `FROM qwen3-vl:4b-instruct`.
   * Register local tag `galaxy-vision:1.0`.
   * Configure domain-specific system identity, grounded vision reasoning instructions, and optimized memory parameters.
   * Preserve upstream `qwen3-vl:4b-instruct` without alteration (providing a clean rollback path).
2. **Software Pipeline:**
   * Provide native Python SDK `galaxy_vision` with unified `GalaxyVision` engine.
   * Provide asynchronous frame sampling for multi-second video visual question answering.
   * Provide document layout & OCR parsing engine.
   * Implement FastAPI production server with OpenAI-compatible chat endpoints and dedicated vision/video endpoints.
   * Provide CLI utility for shell inference and health diagnostics.
3. **Testing & Verification:**
   * Execute real capability benchmarks across text, OCR, diagrams, screenshots, video frames, and structured JSON output.
