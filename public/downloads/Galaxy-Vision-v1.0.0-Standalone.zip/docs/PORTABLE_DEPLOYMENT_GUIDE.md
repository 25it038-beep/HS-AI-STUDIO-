# Portable Deployment & Multi-Interface Sharing Guide

**Product:** HS AI Solutions Galaxy Vision (v1.0.0)  
**Package:** `galaxy-vision-v1.0.0-portable.zip`  
**Target Systems:** Windows 10/11, macOS, Linux  

---

## 1. Quick Transfer & Setup on Any Computer

You can transfer the **`galaxy-vision-v1.0.0-portable.zip`** file to any other computer (via USB drive, LAN share, cloud drive, or email/airdrop).

### Step 1: Extract the Zip File
Unzip `galaxy-vision-v1.0.0-portable.zip` into your desired folder, e.g.:
* **Windows:** `C:\AI\galaxy-vision\`
* **Mac/Linux:** `~/ai/galaxy-vision/`

### Step 2: Ensure Prerequisites Are Installed on the Target Computer
1. **Python 3.10+**: Download from [python.org](https://www.python.org/)
2. **Ollama**: Download from [ollama.com](https://ollama.com/) (or run `curl -fsSL https://ollama.com/install.sh | sh` on Linux)

### Step 3: Run the 1-Click Setup
* **On Windows:**
  Simply double-click **`setup.bat`**.  
  This script automatically:
  * Creates an isolated virtual environment (`.venv`).
  * Installs all dependencies (`opencv-python`, `pillow`, `fastapi`, `streamlit`, etc.).
  * Pulls the base foundation weights `qwen3-vl:4b-instruct` (if not already local).
  * Builds and registers the branded `galaxy-vision:1.0` model tag in Ollama.

* **On Linux / macOS:**
  ```bash
  cd galaxy-vision
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  pip install -e .
  ollama create galaxy-vision:1.0 -f Modelfile
  ```

---

## 2. Universal Interface Options

Galaxy Vision can be operated through **any interface of your choice**:

### Interface 1: Streamlit Multimodal Studio (Recommended for End-Users)
Double-click **`start_web_ui.bat`** (or run `streamlit run web_app.py`).
* Opens in your browser at `http://localhost:8501`.
* Includes drag-and-drop image OCR, tabular extraction, video frame sampling, interactive chat with image attachments, and live VRAM diagnostics.

### Interface 2: Built-in Single-Page Web App
Double-click **`start_api.bat`** and navigate to `http://localhost:8000/`.
* Lightweight dark-mode web application running directly on the FastAPI server with zero external dependencies.

### Interface 3: Open WebUI & LibreChat
1. Launch the API via `start_api.bat` (listens on `0.0.0.0:8000`).
2. In Open WebUI, navigate to **Settings -> Connections -> OpenAI API**.
3. Set **Base URL:** `http://localhost:8000/v1`
4. Set **API Key:** `none` (or any string)
5. Select model: `galaxy-vision:1.0`

### Interface 4: AnythingLLM / Chatbox / LM Studio
1. In the application settings, select LLM Provider: **OpenAI Compatible**.
2. Base URL: `http://127.0.0.1:8000/v1`
3. Model: `galaxy-vision:1.0`

### Interface 5: VS Code, Cursor & Continue.dev
In `~/.continue/config.json`:
```json
{
  "models": [
    {
      "title": "HS AI Galaxy Vision",
      "provider": "openai",
      "model": "galaxy-vision:1.0",
      "apiBase": "http://127.0.0.1:8000/v1"
    }
  ]
}
```

### Interface 6: Official OpenAI Python SDK
Any script that uses `openai` can point to Galaxy Vision without changes:
```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"
)

response = client.chat.completions.create(
    model="galaxy-vision:1.0",
    messages=[
        {"role": "user", "content": "Explain photosynthesis in 2 sentences."}
    ]
)
print(response.choices[0].message.content)
```

### Interface 7: Command-Line Interface (CLI)
Double-click **`start_cli.bat`** or run:
```bash
galaxy-vision text "Hello Galaxy Vision"
galaxy-vision image "photo.jpg" --prompt "Read the text."
galaxy-vision video "clip.mp4" --interval 1.0
```

---

## 3. Sharing Across the Local Network (Wi-Fi / LAN)

Because `start_api.bat` and `start_web_ui.bat` bind to `0.0.0.0`, you can access Galaxy Vision from **any phone, tablet, laptop, or desktop on the same Wi-Fi network**!

1. Find the host computer's local IP address (e.g. `192.168.1.150` via `ipconfig` on Windows).
2. Start the service:
   * **For Web Studio:** `streamlit run web_app.py --server.address 0.0.0.0 --server.port 8501`
   * **For API:** `python -m galaxy_vision.cli serve --host 0.0.0.0 --port 8000`
3. On any other device on the Wi-Fi network, open:
   * Web Studio: `http://192.168.1.150:8501`
   * Web App: `http://192.168.1.150:8000/`
   * API: `http://192.168.1.150:8000/v1`
