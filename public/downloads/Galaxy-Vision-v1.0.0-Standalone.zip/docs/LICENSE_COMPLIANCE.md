# License Compliance & Intellectual Property Ownership

**Product:** HS AI Solutions Galaxy Vision  
**Document Classification:** Legal & Technical Compliance Specification  
**Version:** 1.0.0  
**Effective Date:** October 21, 2026  

---

## 1. Executive Statement of Compliance

HS AI Solutions treats software and machine-learning model licensing as a mandatory engineering discipline. **Galaxy Vision 1.0.0** is distributed under strict adherence to the **Apache License, Version 2.0**, governing the upstream foundation model, together with the respective open-source licenses governing all runtime dependencies.

---

## 2. Upstream Model Licensing Audit

### 2.1 Foundation Model Identity
* **Base Model:** Qwen3-VL 4B Instruct (`qwen3-vl:4b-instruct`)
* **Upstream Licensor:** Alibaba Cloud (Qwen Model Team)
* **License:** Apache License, Version 2.0 (January 2004)
* **Direct Verification:** Verified via Ollama manifest blob (`sha256:16b83b...`) and upstream repository declarations.

### 2.2 Apache 2.0 Obligation Checklist

| Clause | Requirement | HS AI Solutions Implementation | Status |
| :--- | :--- | :--- | :---: |
| **Section 4(a)** | Provide a copy of the License. | Complete text of Apache License 2.0 included in root `LICENSE`. | **COMPLIANT** |
| **Section 4(b)** | Prominent notice of modifications. | Detailed changelog and audit provided in `docs/UPSTREAM_MODEL_AUDIT.md` and `NOTICE`. | **COMPLIANT** |
| **Section 4(c)** | Retain copyright and patent notices. | All upstream copyright and author notices preserved in manifests and source headers. | **COMPLIANT** |
| **Section 4(d)** | Include a `NOTICE` file. | Dedicated `NOTICE` file included acknowledging Alibaba Cloud / Qwen Team authorship. | **COMPLIANT** |
| **Section 6** | Respect Licensor trademarks. | "Qwen" is referenced strictly for origin identification; no endorsement by Alibaba is claimed. | **COMPLIANT** |

---

## 3. Strict Demarcation of Intellectual Property

To prevent misleading claims or copyright infringement, HS AI Solutions explicitly separates original contributions from upstream assets:

### 3.1 Upstream Intellectual Property (Alibaba Cloud / Qwen Team)
* The underlying neural network architecture (Vision Transformer ViT, 2D patch-merging projection layers, and language decoder).
* The 4.4 billion pretrained foundation weights.
* The original tokenizer vocabularies and base chat template parsers.

### 3.2 HS AI Solutions Original Intellectual Property
* **Product Name and Branding:** The "Galaxy Vision", "HS AI Solutions", and "Galaxy" marks and identifiers.
* **Custom Model Configuration:** The Galaxy Vision `Modelfile`, system prompt steering, grounded visual reasoning guidelines, and VRAM-optimized hyperparameter configuration.
* **Software Implementation:** The complete `galaxy_vision` Python package, including:
  * Backend abstraction layer (`inference.py`)
  * Video keyframe sampling and temporal narrative synthesis pipeline (`video.py`)
  * Document layout parsing, markdown table extraction, and structured JSON serializer (`document_processing.py`)
  * Vision validation and aspect-ratio normalization engine (`vision.py`)
  * Production FastAPI REST service with OpenAPI schemas (`api.py`)
  * Terminal CLI utility and rich dashboard (`cli.py`)
  * Real-time hardware health and VRAM diagnostic engine (`health.py`)
* **Verification & Benchmarking Suite:** Capability test suite and 12-category automated evaluation framework.

---

## 4. Third-Party Library Governance

All third-party libraries incorporated into the Galaxy Vision distribution operate under permissive open-source licenses:

* **Ollama & llama.cpp:** MIT License (Local inference server & GGUF runtime)
* **FastAPI:** MIT License (HTTP server framework)
* **Uvicorn:** BSD 3-Clause License (ASGI web server)
* **Pillow (PIL):** HPND License (Image manipulation)
* **OpenCV (opencv-python):** Apache License 2.0 (Video decoding and frame processing)
* **Pydantic & Pydantic-Settings:** MIT License (Data validation)
* **Click & Rich:** BSD 3-Clause / MIT License (CLI rendering)
* **PyTorch & Torchvision:** Modified BSD License (Tensors and GPU inspection)

Third-party copyright notices and terms are cataloged in `THIRD_PARTY_NOTICES.md`.

---

## 5. Ethical Attribution & Non-Fabrication Guarantee

HS AI Solutions affirms that:
1. It does **not** claim to have trained the foundation weights from scratch.
2. It does **not** conceal or obscure the upstream lineage of the base model.
3. Galaxy Vision represents a genuine, functional, and production-engineered model distribution and software system built responsibly upon properly licensed open-source foundations.
