# Galaxy Vision Installation & Operational Guide

**Product:** HS AI Solutions Galaxy Vision  
**Target Operating System:** Windows 10 / 11 (64-bit)  
**Target Hardware:** 16 GB System RAM, NVIDIA RTX 3050 Laptop GPU (6 GB VRAM)  
**Supported Shell:** Windows PowerShell  

---

## 1. Prerequisites Check

Before beginning, ensure that Python and Ollama are installed and accessible on your Windows `PATH`:

```powershell
# 1. Check Python version (>= 3.10 required)
python --version

# 2. Check NVIDIA GPU and Driver status
nvidia-smi

# 3. Check Ollama daemon connectivity
ollama list
```

---

## 2. Verify Upstream Model

Galaxy Vision 1.0.0 uses the upstream `qwen3-vl:4b-instruct` foundation model weights. Check whether the model is already present:

```powershell
ollama list
```

If `qwen3-vl:4b-instruct` is not in the list, pull it using Ollama:

```powershell
ollama pull qwen3-vl:4b-instruct
```

> **Note:** If `qwen3-vl:4b-instruct` is already installed, do **NOT** re-download it. Galaxy Vision reuses the local layer blobs without duplicate network usage.

---

## 3. Python Environment Setup

Navigate to the `galaxy-vision` directory and create an isolated virtual environment:

```powershell
cd galaxy-vision

# Create virtual environment
python -m venv .venv

# Activate virtual environment in PowerShell
.\.venv\Scripts\Activate.ps1

# Upgrade pip
python -m pip install --upgrade pip
```

### Install Dependencies & Galaxy Vision Package
Install the project in editable mode:

```powershell
pip install -e .
```

Alternatively, install requirements directly:

```powershell
pip install -r requirements.txt
```

---

## 4. Register Galaxy Vision Model Tag

Create the customized HS AI Solutions `galaxy-vision:1.0` model tag using the provided `Modelfile`:

```powershell
ollama create galaxy-vision:1.0 -f Modelfile
```

Verify that the new model appears in Ollama:

```powershell
ollama list
```

You should see `galaxy-vision:1.0` alongside `qwen3-vl:4b-instruct`. The original model remains completely intact and unaltered.

---

## 5. Quickstart & Verification

### 5.1 Run Health & Hardware Diagnostics
Check model availability, system RAM, and GPU VRAM utilization:

```powershell
galaxy-vision health
```

### 5.2 Text Generation via CLI
```powershell
galaxy-vision text "Explain the difference between a CPU and a GPU."
```

### 5.3 Multimodal Image Analysis
Run the self-contained image analysis example (automatically creates a sample test image if none exists):

```powershell
python examples/image_example.py
```

Or pass any local image via CLI:

```powershell
galaxy-vision image "C:\path\to\your\image.png" --prompt "Read the text and describe all objects."
```

### 5.4 Video Analysis & Temporal Synthesis
Run the video analysis example (generates a synthetic 3-second multi-phase video and performs keyframe synthesis):

```powershell
python examples/video_example.py
```

Or analyze a custom video:

```powershell
galaxy-vision video "C:\path\to\video.mp4" --interval 1.0 --max-frames 10
```

### 5.5 Document Intelligence & Financial OCR
Run the receipt and table extraction example:

```powershell
python examples/document_example.py
```

---

## 6. Launching the Local REST API

Start the high-performance FastAPI server:

```powershell
# Using the CLI
galaxy-vision serve --host 127.0.0.1 --port 8000

# Or using Uvicorn directly
uvicorn galaxy_vision.api:app --host 127.0.0.1 --port 8000
```

### Access Interactive Documentation
Open your web browser:
* **Interactive Swagger UI:** [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
* **ReDoc Documentation:** [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)

---

## 7. Running the Automated Capability Test Suite

Execute the full pytest suite:

```powershell
pytest tests -v
```

All 14 tests across API, text, image, document, and video frame extraction should report `PASSED`.

---

## 8. Rollback Procedure

If you ever wish to remove the Galaxy Vision customized model tag while retaining the base upstream model:

```powershell
ollama rm galaxy-vision:1.0
```

The upstream `qwen3-vl:4b-instruct` model and its underlying cached weights will remain fully functional and untouched.
