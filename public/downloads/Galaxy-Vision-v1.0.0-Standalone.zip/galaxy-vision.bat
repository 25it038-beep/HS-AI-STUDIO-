@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

if exist ".venv\Scripts\activate.bat" (
    call ".venv\Scripts\activate.bat"
)

if "%~1"=="" (
    python -m galaxy_vision.cli chat
) else (
    python -m galaxy_vision.cli %*
)
