@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

title Galaxy Vision Desktop App - HS AI Solutions

echo.
echo ================================================================
echo   HS AI Solutions Galaxy Vision 1.0.0
echo   Standalone Native Desktop Application
echo   ----------------------------------------------------------------
echo   HS AI SOLUTIONS : https://hs-ai-studio-4i7i.vercel.app/
echo ================================================================
echo.

:: Step 1: Activate virtual environment if present
if exist ".venv\Scripts\activate.bat" (
    call ".venv\Scripts\activate.bat"
    echo [OK] Virtual environment activated.
)

:: Step 2: Ensure silent local inference daemon is running in background
where ollama >nul 2>&1
if not errorlevel 1 (
    netstat -ano | findstr /R /C:":11434 .*LISTENING" >nul 2>&1
    if errorlevel 1 (
        echo [INFO] Initializing inference engine daemon in background...
        start /b "" ollama serve >nul 2>&1
        timeout /t 2 /nobreak >nul 2>&1
    )
)

:: Step 3: Launch desktop application
python -m galaxy_vision.desktop

if errorlevel 1 (
    echo.
    echo [ERROR] Desktop app exited with an issue.
    pause
)
