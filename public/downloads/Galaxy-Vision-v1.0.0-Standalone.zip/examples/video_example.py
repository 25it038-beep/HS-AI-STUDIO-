import pygame
import numpy as np
import imageio
import imageio.ffmpeg
from math import sin, cos, pi, sqrt, radians, degrees

# === CONFIG ===
WIDTH, HEIGHT = 1920, 1080
FPS = 30
FRAME_DURATION = 1.0 / FPS  # seconds per frame

# === INIT ===
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.DOUBLEBUF | pygame.SCALED)
pygame.display.set_caption("HS AI SOLUTIONS — Digital Eyes Cinematic")

clock = pygame.time.Clock()

# === COLORS ===
BLACK = (0, 0, 0)
CYAN = (0, 255, 255)
WHITE = (255, 255, 255)
GRAY = (100, 100, 100)

# === PARTICLE SYSTEM ===
class Particle:
    def __init__(self, x, y, vx, vy, life=100):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.life = life
        self.radius = np.random.uniform(1, 3)
        self.color = (np.random.randint(0, 255), np.random.randint(0, 255), np.random.randint(0, 255))
        self.angle = np.random.uniform(0, 2*pi)
        self.lifetime = 100

    def update(self):
        self.life -= 1