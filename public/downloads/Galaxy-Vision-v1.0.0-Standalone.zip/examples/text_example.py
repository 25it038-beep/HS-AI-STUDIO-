"""Text generation example using HS AI Solutions Galaxy Vision."""

import sys
from pathlib import Path

# Add project root to path for local execution
sys.path.insert(0, str(Path(__file__).parent.parent))

from galaxy_vision import GalaxyVision


def main():
    print("=" * 60)
    print("HS AI Solutions Galaxy Vision — Text Generation Example")
    print("=" * 60)

    # Initialize Galaxy Vision
    model = GalaxyVision()
    print(f"Active Model: {model.model_name}")

    # Generate explanation
    prompt = "Explain the difference between a CPU and a GPU in 3 concise bullet points."
    print(f"\nPrompt: {prompt}\n")

    response = model.generate(prompt=prompt)

    print("Response:")
    print(response.text)
    print("\nMetrics:")
    print(f"- Total duration: {response.total_duration_sec:.2f} seconds")
    print(f"- Tokens generated: {response.completion_tokens}")


if __name__ == "__main__":
    main()
