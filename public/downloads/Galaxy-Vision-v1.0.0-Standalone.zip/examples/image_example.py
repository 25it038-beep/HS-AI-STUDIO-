"""Multimodal image analysis example using HS AI Solutions Galaxy Vision."""

import io
import sys
from pathlib import Path
from PIL import Image, ImageDraw

# Add project root to path for local execution
sys.path.insert(0, str(Path(__file__).parent.parent))

from galaxy_vision import GalaxyVision


def create_sample_image(path: Path) -> Path:
    """Generate a sample test image with geometric shapes and clear OCR text."""
    img = Image.new("RGB", (500, 250), color=(24, 32, 54))
    draw = ImageDraw.Draw(img)

    # Draw shapes
    draw.rectangle([30, 40, 160, 210], fill=(59, 130, 246), outline=(255, 255, 255), width=2)
    draw.ellipse([340, 40, 470, 170], fill=(234, 88, 12), outline=(255, 255, 255), width=2)

    # Draw text
    draw.text((180, 70), "HS AI SOLUTIONS", fill=(255, 255, 255))
    draw.text((180, 100), "GALAXY VISION 1.0", fill=(52, 211, 153))
    draw.text((180, 130), "Multimodal Vision AI", fill=(203, 213, 225))

    img.save(path, format="PNG")
    return path


def main():
    print("=" * 60)
    print("HS AI Solutions Galaxy Vision — Image Analysis Example")
    print("=" * 60)

    # Initialize Galaxy Vision
    model = GalaxyVision()
    print(f"Active Model: {model.model_name}")

    # Generate or find sample image
    sample_path = Path(__file__).parent / "sample.png"
    if not sample_path.exists():
        print(f"Generating synthetic sample image at: {sample_path}")
        create_sample_image(sample_path)

    prompt = "Describe the objects, colors, and exact text visible in this image."
    print(f"\nAnalyzing image: {sample_path}")
    print(f"Prompt: {prompt}\n")

    response = model.analyze_image(
        image_path=sample_path,
        prompt=prompt
    )

    print("Response:")
    print(response.text)
    print("\nMetrics:")
    print(f"- Total duration: {response.total_duration_sec:.2f} seconds")
    print(f"- Tokens generated: {response.completion_tokens}")


if __name__ == "__main__":
    main()
