"""Document intelligence and receipt extraction example using Galaxy Vision."""

import sys
from pathlib import Path
from PIL import Image, ImageDraw

# Add project root to path for local execution
sys.path.insert(0, str(Path(__file__).parent.parent))

from galaxy_vision import GalaxyVision


def create_sample_receipt(path: Path) -> Path:
    """Generate a synthetic receipt image for testing OCR and structured extraction."""
    img = Image.new("RGB", (600, 450), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)

    # Header
    draw.text((200, 30), "HS AI TECH STORE", fill=(0, 0, 0))
    draw.text((190, 60), "INVOICE #HS-2026-904", fill=(80, 80, 80))
    draw.text((220, 90), "Date: 2026-10-21", fill=(80, 80, 80))
    draw.line([(40, 120), (560, 120)], fill=(180, 180, 180), width=1)

    # Table Header
    draw.text((50, 140), "ITEM", fill=(0, 0, 0))
    draw.text((320, 140), "QTY", fill=(0, 0, 0))
    draw.text((450, 140), "PRICE", fill=(0, 0, 0))
    draw.line([(40, 170), (560, 170)], fill=(180, 180, 180), width=1)

    # Items
    items = [
        ("RTX 3050 Laptop GPU Adapter", "1", "$89.00"),
        ("16GB DDR5 High-Speed RAM", "2", "$130.00"),
        ("Galaxy Vision Enterprise License", "1", "$250.00"),
    ]
    y = 190
    for name, qty, price in items:
        draw.text((50, y), name, fill=(40, 40, 40))
        draw.text((330, y), qty, fill=(40, 40, 40))
        draw.text((450, y), price, fill=(40, 40, 40))
        y += 35

    draw.line([(40, y + 10), (560, y + 10)], fill=(180, 180, 180), width=1)
    y += 30
    draw.text((300, y), "Subtotal:", fill=(40, 40, 40))
    draw.text((450, y), "$469.00", fill=(40, 40, 40))
    y += 30
    draw.text((300, y), "Tax (10%):", fill=(40, 40, 40))
    draw.text((450, y), "$46.90", fill=(40, 40, 40))
    y += 30
    draw.text((300, y), "TOTAL:", fill=(0, 0, 0))
    draw.text((450, y), "$515.90", fill=(0, 150, 0))

    img.save(path, format="PNG")
    return path


def main():
    print("=" * 60)
    print("HS AI Solutions Galaxy Vision — Document & OCR Example")
    print("=" * 60)

    # Initialize Galaxy Vision
    model = GalaxyVision()
    print(f"Active Model: {model.model_name}")

    # Generate sample receipt
    sample_receipt_path = Path(__file__).parent / "sample_receipt.png"
    if not sample_receipt_path.exists():
        print(f"Generating synthetic receipt at: {sample_receipt_path}")
        create_sample_receipt(sample_receipt_path)

    print(f"\nProcessing Document: {sample_receipt_path}\n")

    result = model.analyze_document(
        document_path=sample_receipt_path,
        extract_tables=True,
        return_json=True
    )

    print("Document Text & Layout Transcription:")
    print(result.text)

    if result.tables:
        print("\nExtracted Table Count:", len(result.tables))
        for idx, tbl in enumerate(result.tables):
            print(f"Table {idx+1}: Headers = {tbl['headers']}, Rows = {len(tbl['rows'])}")

    if result.structured_data:
        print("\nStructured JSON Output:")
        import json
        print(json.dumps(result.structured_data, indent=2))

    print(f"\nProcessing Latency: {result.latency_sec:.2f}s")


if __name__ == "__main__":
    main()
