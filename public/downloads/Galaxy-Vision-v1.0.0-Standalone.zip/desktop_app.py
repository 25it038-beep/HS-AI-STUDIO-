#!/usr/bin/env python3
"""Launcher for HS AI Solutions Galaxy Vision Desktop Application."""

import sys
from galaxy_vision.desktop import launch_desktop_app

if __name__ == "__main__":
    launch_desktop_app()
